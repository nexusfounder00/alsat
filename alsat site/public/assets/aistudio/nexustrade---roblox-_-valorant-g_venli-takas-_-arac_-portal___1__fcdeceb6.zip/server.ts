import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import crypto from 'crypto';
import { User, AuthResponse } from './src/types/auth';
import { Listing } from './src/types/listing';
import {
  USERNAME_REGEX,
  validateUsername,
  validatePassword,
  validateDiscordTag,
  validateListingInput,
  calculateRemainingCooldown,
} from './src/utils/validation';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// JSON ve URLencoded yük limiti (Yüklenen fotoğrafların Base64 olarak sunucuya aktarılabilmesi için 15MB)
app.use(express.json({ limit: '15mb' }));
app.use(express.urlencoded({ limit: '15mb', extended: true }));

// Uploads ve Data klasörleri
const dataDir = path.resolve(__dirname, 'data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const uploadsDir = path.resolve(__dirname, 'public', 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// ==========================================
// KALICI VERİ DEPOLAMA (PERSISTENT STORAGE)
// ==========================================
// Sunucu kapansa veya yeniden başlasa dahi kullanıcı hesapları ve ilanlar asla kaybolmaz.
const STORE_FILE = path.join(dataDir, 'alsat_store.json');
const SECRET_FILE = path.join(dataDir, 'session_secret.key');

// Deterministik oturum imzalama anahtarı (Kalıcı olarak dosyada saklanır)
let sessionSecret = 'alsat_secure_session_token_key_2026';
if (fs.existsSync(SECRET_FILE)) {
  try {
    sessionSecret = fs.readFileSync(SECRET_FILE, 'utf8').trim() || sessionSecret;
  } catch {
    // fallback
  }
} else {
  try {
    fs.writeFileSync(SECRET_FILE, sessionSecret, 'utf8');
  } catch {
    // fallback
  }
}

interface StoredUser extends User {
  passwordHash: string;
}

interface StoreData {
  users: StoredUser[];
  listings: Listing[];
  revokedTokens: string[];
}

let usersDb: StoredUser[] = [];
let listingsDb: Listing[] = [];
const revokedTokensSet = new Set<string>();

// Veritabanını diskten yükle
function loadStore() {
  if (fs.existsSync(STORE_FILE)) {
    try {
      const raw = fs.readFileSync(STORE_FILE, 'utf8');
      const data: StoreData = JSON.parse(raw);
      usersDb = Array.isArray(data.users) ? data.users : [];
      listingsDb = Array.isArray(data.listings) ? data.listings : [];
      if (Array.isArray(data.revokedTokens)) {
        data.revokedTokens.forEach((t) => revokedTokensSet.add(t));
      }
      console.log(`[Depo] ${usersDb.length} kullanıcı ve ${listingsDb.length} ilan yüklendi.`);
    } catch (err) {
      console.error('[Depo Yükleme Hatası]:', err);
    }
  }
}

// Veritabanını diske kaydet
function saveStore() {
  try {
    const data: StoreData = {
      users: usersDb,
      listings: listingsDb,
      revokedTokens: Array.from(revokedTokensSet).slice(-500),
    };
    fs.writeFileSync(STORE_FILE, JSON.stringify(data, null, 2), 'utf8');
  } catch (err) {
    console.error('[Depo Kaydetme Hatası]:', err);
  }
}

loadStore();

// ==========================================
// KALICI VE GÜVENLİ TOKEN SİSTEMİ (30 GÜN GEÇERLİ, PERSISTENT SESSION)
// ==========================================
// Rastgele string veya uuid KULLANILMAZ; HMAC-SHA256 imzalı deterministik token kullanılır.
interface TokenPayload {
  uid: string;
  u: string;
  d: string;
  exp: number;
}

function createAuthToken(user: StoredUser): string {
  const payload: TokenPayload = {
    uid: user.id,
    u: user.username,
    d: user.discordTag,
    exp: Date.now() + 30 * 24 * 60 * 60 * 1000, // 30 gün boyunca geçerli
  };
  const payloadB64 = Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
  const signature = crypto.createHmac('sha256', sessionSecret).update(payloadB64).digest('base64url');
  return `${payloadB64}.${signature}`;
}

function verifyAuthToken(token: string): StoredUser | null {
  if (!token || typeof token !== 'string' || !token.includes('.')) return null;
  if (revokedTokensSet.has(token)) return null;

  const [payloadB64, signature] = token.split('.');
  if (!payloadB64 || !signature) return null;

  const expectedSignature = crypto.createHmac('sha256', sessionSecret).update(payloadB64).digest('base64url');
  if (signature !== expectedSignature) return null;

  try {
    const payload: TokenPayload = JSON.parse(Buffer.from(payloadB64, 'base64url').toString('utf8'));
    if (!payload.uid || !payload.exp || Date.now() > payload.exp) {
      return null;
    }
    return usersDb.find((u) => u.id === payload.uid) || null;
  } catch {
    return null;
  }
}

function hashPassword(password: string): string {
  return crypto.createHash('sha256').update(password + '_alsat_roblox_market_2026').digest('hex');
}

// Anti-Spam Rate Limit Haritası: userId -> son ilan ekleme timestamp'i
const listingRateLimitMap = new Map<string, number>();
const LISTING_COOLDOWN_MS = 60 * 1000; // Kullanıcı başına dakikada en fazla 1 ilan

function getAuthUser(req: express.Request): StoredUser | null {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) return null;
  const token = authHeader.replace('Bearer ', '').trim();
  return verifyAuthToken(token);
}

// ==========================================
// ARKA PLAN DISCORD WEBHOOK GÖNDERİCİ
// ==========================================
// Sitede hiçbir metin olarak görünmez, sadece arka planda yeni ilan oluşunca tetiklenir.
const DISCORD_WEBHOOK_URL =
  process.env.DISCORD_WEBHOOK_URL ||
  'https://discord.com/api/webhooks/1568320481369530518/tUXZnP8axZaVSIukU_Dmh2FFqg3EG7P1sC6UfJ8JEf5KtivP738rBHAIwg630TUxDZib';

async function sendDiscordWebhookWithImage(options: {
  content?: string;
  embed: any;
  fileBuffer?: Buffer;
  fileName?: string;
}): Promise<{ success: boolean; status?: number; error?: string }> {
  try {
    let bodyData: any;
    let headers: Record<string, string> = {};

    if (options.fileBuffer && options.fileName) {
      // Discord Webhook Multipart Form-Data (Görsel dosyası ekleme)
      const boundary = '----AlsatBoundary' + Date.now();
      headers['Content-Type'] = `multipart/form-data; boundary=${boundary}`;

      const payloadJson = JSON.stringify({
        content: options.content,
        embeds: [options.embed],
      });

      const preJson = `--${boundary}\r\nContent-Disposition: form-data; name="payload_json"\r\nContent-Type: application/json\r\n\r\n${payloadJson}\r\n`;
      const preFile = `--${boundary}\r\nContent-Disposition: form-data; name="files[0]"; filename="${options.fileName}"\r\nContent-Type: image/jpeg\r\n\r\n`;
      const postFile = `\r\n--${boundary}--\r\n`;

      bodyData = Buffer.concat([
        Buffer.from(preJson, 'utf8'),
        Buffer.from(preFile, 'utf8'),
        options.fileBuffer,
        Buffer.from(postFile, 'utf8'),
      ]);
    } else {
      headers['Content-Type'] = 'application/json';
      bodyData = JSON.stringify({
        content: options.content,
        embeds: [options.embed],
      });
    }

    const response = await fetch(DISCORD_WEBHOOK_URL, {
      method: 'POST',
      headers,
      body: bodyData,
    });

    if (!response.ok) {
      const errText = await response.text();
      console.error(`[Discord Webhook Hatası HTTP ${response.status}]:`, errText);
      return { success: false, status: response.status, error: errText };
    }

    console.log(`[Discord Webhook] Başarıyla iletildi (HTTP ${response.status})`);
    return { success: true, status: response.status };
  } catch (err: any) {
    console.error('[Discord Webhook İstisnası]:', err.message || err);
    return { success: false, error: err.message || 'Ağ bağlantı hatası' };
  }
}

// ==========================================
// REST API ROTALARI
// ==========================================

// Sağlık kontrolü
app.get('/api/health', (req, res) => {
  res.json({
    status: 'online',
    appName: 'Alsat - Roblox Adopt Me! & MM2 İlan Pazarı',
    totalUsers: usersDb.length,
    totalListings: listingsDb.length,
  });
});

// ------------------------------------------
// AUTH: KAYIT VE GİRİŞ (SIKI GİRDİ DOĞRULAMASI, PERSISTENT SESSION)
// ------------------------------------------
app.post('/api/auth/register', (req, res) => {
  const { username, password, discordTag } = req.body;

  // 1. Kullanıcı adı kontrolü & Strict Regex (/^[a-zA-Z0-9_]{3,20}$/)
  const usernameCheck = validateUsername(username);
  if (!usernameCheck.isValid) {
    return res.status(400).json({ error: usernameCheck.error });
  }
  const cleanUsername = (username as string).trim();

  // 2. Şifre Kriteri: En az 6 karakter
  const passwordCheck = validatePassword(password);
  if (!passwordCheck.isValid) {
    return res.status(400).json({ error: passwordCheck.error });
  }

  // 3. Zorunlu Discord Adı ve Etiketi: Kesinlikle zorunlu
  const discordCheck = validateDiscordTag(discordTag);
  if (!discordCheck.isValid) {
    return res.status(400).json({ error: discordCheck.error });
  }

  // Benzersiz kullanıcı adı kontrolü
  const existing = usersDb.find((u) => u.username.toLowerCase() === cleanUsername.toLowerCase());
  if (existing) {
    return res.status(400).json({ error: 'Bu kullanıcı adı zaten kayıtlı. Başka bir isim deneyin.' });
  }

  // Deterministik Kullanıcı ID
  const userId = `usr_${cleanUsername.toLowerCase()}`;

  const newUser: StoredUser = {
    id: userId,
    username: cleanUsername,
    passwordHash: hashPassword(password),
    discordTag: (discordTag as string).trim(),
    createdAt: new Date().toISOString(),
  };

  usersDb.unshift(newUser);
  saveStore();

  const token = createAuthToken(newUser);
  const { passwordHash, ...safeUser } = newUser;

  res.status(201).json({
    success: true,
    user: safeUser,
    token,
  });
});

app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ error: 'Lütfen kullanıcı adı ve şifrenizi girin.' });
  }

  const cleanUsername = (username as string).trim();
  const user = usersDb.find((u) => u.username.toLowerCase() === cleanUsername.toLowerCase());

  if (!user || user.passwordHash !== hashPassword(password)) {
    return res.status(401).json({ error: 'Hatalı kullanıcı adı veya şifre.' });
  }

  const token = createAuthToken(user);
  const { passwordHash, ...safeUser } = user;

  res.json({
    success: true,
    user: safeUser,
    token,
  });
});

app.post('/api/auth/logout', (req, res) => {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.replace('Bearer ', '').trim();
    revokedTokensSet.add(token);
    saveStore();
  }
  res.json({ success: true });
});

app.get('/api/auth/me', (req, res) => {
  const user = getAuthUser(req);
  if (!user) {
    return res.status(401).json({ error: 'Oturum bulunamadı veya süresi doldu.' });
  }
  const { passwordHash, ...safeUser } = user;
  res.json({ user: safeUser });
});

// ------------------------------------------
// İLAN PAZARI (MARKETPLACE) VE ANTH-SPAM SİSTEMİ
// ------------------------------------------

// İlanları listeleme (Oyun ve arama filtresi)
app.get('/api/listings', (req, res) => {
  const { game, search } = req.query;

  let results = [...listingsDb];

  if (game && (game === 'MM2' || game === 'Adopt Me!')) {
    results = results.filter((l) => l.game === game);
  }

  if (search && typeof search === 'string' && search.trim()) {
    const q = search.trim().toLowerCase();
    results = results.filter(
      (l) =>
        l.title.toLowerCase().includes(q) ||
        l.description.toLowerCase().includes(q) ||
        l.ownerUsername.toLowerCase().includes(q) ||
        l.ownerDiscordTag.toLowerCase().includes(q) ||
        l.offeredItemsText.toLowerCase().includes(q) ||
        l.lookingForText.toLowerCase().includes(q)
    );
  }

  res.json({ listings: results, count: results.length });
});

// Tekil ilan getirme
app.get('/api/listings/:id', (req, res) => {
  const listing = listingsDb.find((l) => l.id === req.params.id);
  if (!listing) {
    return res.status(404).json({ error: 'İlan bulunamadı.' });
  }
  res.json({ listing });
});

// YENİ İLAN YAYINLAMA (CİHAZDAN FOTOĞRAF YÜKLEME & ARKA PLAN DISCORD WEBHOOK)
app.post('/api/listings', async (req, res) => {
  const user = getAuthUser(req);
  if (!user) {
    return res.status(401).json({ error: 'İlan verebilmek için giriş yapmalısınız.' });
  }

  // 1. KATI ANTI-SPAM KORUMASI (Kullanıcı başına dakikada en fazla 1 ilan)
  const now = Date.now();
  const lastListingTime = listingRateLimitMap.get(user.id) || 0;
  const remainingCooldown = calculateRemainingCooldown(lastListingTime, now, LISTING_COOLDOWN_MS);

  if (remainingCooldown > 0) {
    return res.status(429).json({
      error: `Spam koruması aktif! Yeni bir ilan vermeden önce lütfen ${remainingCooldown} saniye bekleyin.`,
    });
  }

  const { game, title, description, offeredItemsText, lookingForText, imageBase64 } = req.body;

  // Girdi doğrulamaları
  const validation = validateListingInput({ game, title, description, offeredItemsText, lookingForText });
  if (!validation.isValid) {
    return res.status(400).json({ error: validation.error });
  }

  // 2. KOPYA İLAN KONTROLÜ
  const isDuplicate = listingsDb.some(
    (l) => l.ownerId === user.id && l.title.trim().toLowerCase() === (title as string).trim().toLowerCase()
  );
  if (isDuplicate) {
    return res.status(400).json({ error: 'Zaten aynı başlığa sahip aktif bir ilanınız bulunuyor.' });
  }

  // Deterministik İlan ID'si
  const listingId = `LIST-${Date.now()}`;
  const isoTime = new Date().toISOString();

  // Dosyadan yüklenen Base64 görseli sunucuya kaydetme
  let savedImageUrl: string | undefined = undefined;
  let fileBuffer: Buffer | undefined = undefined;
  let uploadFileName: string | undefined = undefined;

  if (imageBase64 && typeof imageBase64 === 'string' && imageBase64.includes('base64,')) {
    try {
      const parts = imageBase64.split(';base64,');
      const mime = parts[0].replace('data:', '');
      const rawData = parts[1];
      const ext = mime.includes('png') ? 'png' : mime.includes('webp') ? 'webp' : 'jpg';

      uploadFileName = `${listingId}.${ext}`;
      const filePath = path.join(uploadsDir, uploadFileName);
      fileBuffer = Buffer.from(rawData, 'base64');
      fs.writeFileSync(filePath, fileBuffer);

      savedImageUrl = `/uploads/${uploadFileName}`;
    } catch (err) {
      console.error('[Upload Parse Error]:', err);
    }
  }

  const newListing: Listing = {
    id: listingId,
    ownerId: user.id,
    ownerUsername: user.username,
    ownerDiscordTag: user.discordTag,
    game,
    title: (title as string).trim(),
    description: (description as string).trim(),
    offeredItemsText: (offeredItemsText as string).trim(),
    lookingForText: (lookingForText as string).trim(),
    imageUrl: savedImageUrl,
    status: 'ACTIVE',
    createdAt: isoTime,
  };

  listingsDb.unshift(newListing);
  listingRateLimitMap.set(user.id, now);
  saveStore();

  // 3. ARKA PLANDA DISCORD WEBHOOK GÖNDERİMİ (Sitede hiçbir metin olarak görünmez)
  const webhookEmbed: any = {
    title: `📢 YENİ İLAN YAYINLANDI! [${game}]`,
    description: `**${newListing.title}**\n\n${newListing.description}`,
    color: game === 'MM2' ? 0xe11d48 : 0x10b981,
    fields: [
      {
        name: '👤 İlan Sahibi',
        value: `**${user.username}**`,
        inline: true,
      },
      {
        name: '💬 Discord İletişim',
        value: `\`${user.discordTag}\``,
        inline: true,
      },
      {
        name: '🎮 Oyun',
        value: game,
        inline: true,
      },
      {
        name: '🎁 Verdiği / Sunduğu',
        value: newListing.offeredItemsText,
        inline: false,
      },
      {
        name: '🎯 Aradığı / İstediği',
        value: newListing.lookingForText,
        inline: false,
      },
    ],
    footer: {
      text: 'Alsat İlan Pazarı • Discord Üzerinden İletişim',
    },
    timestamp: isoTime,
  };

  if (fileBuffer && uploadFileName) {
    webhookEmbed.image = { url: `attachment://${uploadFileName}` };
  }

  sendDiscordWebhookWithImage({
    content: `📢 **Yeni İlan Yayınlandı!** [${game}] - İlan Sahibi: **${user.username}** (Discord: \`${user.discordTag}\`)`,
    embed: webhookEmbed,
    fileBuffer,
    fileName: uploadFileName,
  }).catch((err) => console.error('[Listing Webhook Error]:', err));

  res.status(201).json({
    success: true,
    listing: newListing,
    message: 'İlanınız başarıyla vitrinde yayınlandı!',
  });
});

// Vite & Server Start
async function startServer() {
  // Statik yüklenen dosyalar servisi
  app.use('/uploads', express.static(uploadsDir));

  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true, hmr: process.env.DISABLE_HMR !== 'true' },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`🚀 Alsat İlan Pazarı Sunucusu Port ${port} üzerinde hazır!`);
  });
}

startServer();
