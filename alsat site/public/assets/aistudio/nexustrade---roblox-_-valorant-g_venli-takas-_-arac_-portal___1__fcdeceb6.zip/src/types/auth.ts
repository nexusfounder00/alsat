export interface User {
  id: string;
  username: string;
  discordTag: string; // Kullanıcının Discord üzerinden ulaşılabileceği adı (Örn: @kullaniciadi veya kullaniciadi#1234)
  createdAt: string;
}

export interface AuthResponse {
  success: boolean;
  user: User;
  token: string;
  message?: string;
}
