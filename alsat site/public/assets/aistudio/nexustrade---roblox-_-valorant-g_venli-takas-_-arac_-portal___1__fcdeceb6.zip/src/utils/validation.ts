/**
 * Validation utilities for Alsat Marketplace
 * Strictly disallows random string generation, validates manual username, password, discordTag and listings
 */

export const USERNAME_REGEX = /^[a-zA-Z0-9_]{3,20}$/;

export interface ValidationResult {
  isValid: boolean;
  error?: string;
}

export function validateUsername(username: unknown): ValidationResult {
  if (!username || typeof username !== 'string') {
    return { isValid: false, error: 'Kullanıcı adı zorunludur.' };
  }
  const clean = username.trim();
  if (!USERNAME_REGEX.test(clean)) {
    return {
      isValid: false,
      error: 'Kullanıcı adı sadece harf, rakam ve alt çizgi (_) içerebilir (3-20 karakter).',
    };
  }
  return { isValid: true };
}

export function validatePassword(password: unknown): ValidationResult {
  if (!password || typeof password !== 'string' || password.trim().length < 6) {
    return {
      isValid: false,
      error: 'Şifre alanı zorunludur ve en az 6 karakter olmalıdır.',
    };
  }
  return { isValid: true };
}

export function validateDiscordTag(discordTag: unknown): ValidationResult {
  if (!discordTag || typeof discordTag !== 'string' || discordTag.trim().length < 3) {
    return {
      isValid: false,
      error: 'Discord Kullanıcı Adı ve Etiketi KESİNLİKLE ZORUNLUDUR (Örn: @kullaniciadi veya mehmet#1234).',
    };
  }
  return { isValid: true };
}

export interface ListingInput {
  game: string;
  title: string;
  description: string;
  offeredItemsText: string;
  lookingForText: string;
}

export function validateListingInput(input: Partial<ListingInput>): ValidationResult {
  if (!input.game || (input.game !== 'MM2' && input.game !== 'Adopt Me!')) {
    return { isValid: false, error: 'Lütfen geçerli bir oyun seçin (MM2 veya Adopt Me!).' };
  }
  if (!input.title || typeof input.title !== 'string' || input.title.trim().length < 4) {
    return { isValid: false, error: 'İlan başlığı en az 4 karakter olmalıdır.' };
  }
  if (!input.offeredItemsText || typeof input.offeredItemsText !== 'string' || input.offeredItemsText.trim().length === 0) {
    return { isValid: false, error: 'Lütfen verdiğiniz / sunduğunuz şeyleri yazın.' };
  }
  if (!input.lookingForText || typeof input.lookingForText !== 'string' || input.lookingForText.trim().length === 0) {
    return { isValid: false, error: 'Lütfen aradığınız / istediğiniz şeyleri yazın.' };
  }
  if (!input.description || typeof input.description !== 'string' || input.description.trim().length < 6) {
    return { isValid: false, error: 'İlan açıklaması en az 6 karakter olmalıdır.' };
  }
  return { isValid: true };
}

export function calculateRemainingCooldown(lastListingTimestamp: number, now: number, cooldownMs = 60000): number {
  const elapsed = now - lastListingTimestamp;
  if (elapsed >= cooldownMs) return 0;
  return Math.ceil((cooldownMs - elapsed) / 1000);
}
