import test from 'node:test';
import assert from 'node:assert/strict';
import {
  validateUsername,
  validatePassword,
  validateDiscordTag,
  validateListingInput,
  calculateRemainingCooldown,
  USERNAME_REGEX,
} from './validation';

test('USERNAME_REGEX accepts valid usernames', () => {
  assert.equal(USERNAME_REGEX.test('ahmet_23'), true);
  assert.equal(USERNAME_REGEX.test('proGamer'), true);
  assert.equal(USERNAME_REGEX.test('mm2_king'), true);
  assert.equal(USERNAME_REGEX.test('Robloxian_1'), true);
});

test('USERNAME_REGEX rejects invalid usernames and random hashes with illegal symbols', () => {
  assert.equal(USERNAME_REGEX.test('ab'), false); // too short (<3)
  assert.equal(USERNAME_REGEX.test('a'.repeat(21)), false); // too long (>20)
  assert.equal(USERNAME_REGEX.test('user@name'), false); // invalid character @
  assert.equal(USERNAME_REGEX.test('user-name'), false); // hyphen not in regex
  assert.equal(USERNAME_REGEX.test('8fcp5yHLcxgExWc8ddeM6znVTA3jFXNbdVcpRTcr7TY4'), false); // 44 chars long hash
  assert.equal(USERNAME_REGEX.test(''), false);
});

test('validateUsername handles empty and non-string inputs', () => {
  assert.equal(validateUsername('').isValid, false);
  assert.equal(validateUsername(null).isValid, false);
  assert.equal(validateUsername(undefined).isValid, false);
  assert.equal(validateUsername('valid_name').isValid, true);
});

test('validatePassword requires at least 6 characters', () => {
  assert.equal(validatePassword('12345').isValid, false);
  assert.equal(validatePassword('123456').isValid, true);
  assert.equal(validatePassword('secure_password').isValid, true);
});

test('validateDiscordTag requires at least 3 characters', () => {
  assert.equal(validateDiscordTag('').isValid, false);
  assert.equal(validateDiscordTag('ab').isValid, false);
  assert.equal(validateDiscordTag('@oyuncu').isValid, true);
  assert.equal(validateDiscordTag('oyuncu#1234').isValid, true);
});

test('validateListingInput checks all mandatory listing fields', () => {
  const valid = {
    game: 'MM2',
    title: 'Harvester Satılık',
    offeredItemsText: 'Harvester',
    lookingForText: 'Corrupt Set',
    description: 'Discord üzerinden mesaj atabilirsiniz',
  };
  assert.equal(validateListingInput(valid).isValid, true);

  // Missing title
  assert.equal(validateListingInput({ ...valid, title: 'ab' }).isValid, false);

  // Invalid game
  assert.equal(validateListingInput({ ...valid, game: 'Fortnite' }).isValid, false);

  // Missing offered items
  assert.equal(validateListingInput({ ...valid, offeredItemsText: '' }).isValid, false);

  // Missing looking for
  assert.equal(validateListingInput({ ...valid, lookingForText: '' }).isValid, false);
});

test('calculateRemainingCooldown correctly calculates seconds', () => {
  const now = 100000;
  // 30 seconds ago
  const remaining = calculateRemainingCooldown(now - 30000, now, 60000);
  assert.equal(remaining, 30);

  // 60 seconds ago (cooldown expired)
  const expired = calculateRemainingCooldown(now - 60000, now, 60000);
  assert.equal(expired, 0);

  // 70 seconds ago
  const past = calculateRemainingCooldown(now - 70000, now, 60000);
  assert.equal(past, 0);
});
