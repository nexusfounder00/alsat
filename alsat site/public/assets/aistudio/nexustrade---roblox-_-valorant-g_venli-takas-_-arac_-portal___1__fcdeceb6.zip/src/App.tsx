import React, { useState, useEffect, useCallback } from 'react';
import {
  Search,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Layers,
  Flame,
  PlusCircle,
  MessageCircle,
} from 'lucide-react';
import { Navbar } from './components/Navbar';
import { ListingCard } from './components/ListingCard';
import { CreateListingModal } from './components/CreateListingModal';
import { AuthModal } from './components/AuthModal';
import { LiveBackground } from './components/LiveBackground';
import { User, AuthResponse } from './types/auth';
import { Listing } from './types/listing';

const TOKEN_KEY = 'alsat_auth_token';

export default function App() {
  const [selectedGame, setSelectedGame] = useState<'Adopt Me!' | 'MM2' | 'ALL'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  // Listings state
  const [listings, setListings] = useState<Listing[]>([]);
  const [isLoadingListings, setIsLoadingListings] = useState(true);

  // Authentication state
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(() => localStorage.getItem(TOKEN_KEY));
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isCreateListingOpen, setIsCreateListingOpen] = useState(false);

  // Global toast notification
  const [toastMessage, setToastMessage] = useState<{ type: 'success' | 'alert' | 'error' | 'info'; text: string } | null>(null);

  const showToast = (type: 'success' | 'alert' | 'error' | 'info', text: string) => {
    setToastMessage({ type, text });
    setTimeout(() => {
      setToastMessage((prev) => (prev?.text === text ? null : prev));
    }, 4500);
  };

  // Verify stored auth token (persistent session)
  useEffect(() => {
    if (token) {
      fetch('/api/auth/me', {
        headers: { Authorization: `Bearer ${token}` },
      })
        .then((res) => (res.ok ? res.json() : null))
        .then((data) => {
          if (data?.user) {
            setCurrentUser(data.user);
          } else {
            localStorage.removeItem(TOKEN_KEY);
            setToken(null);
            setCurrentUser(null);
          }
        })
        .catch(() => {
          // Ağ hatası veya geçici kesintilerde hemen oturumu silme; oturum kalıcı kalır
        });
    }
  }, [token]);

  const handleAuthSuccess = (data: AuthResponse) => {
    localStorage.setItem(TOKEN_KEY, data.token);
    setToken(data.token);
    setCurrentUser(data.user);
    showToast('success', `Hoş geldin, ${data.user.username}! Alsat hesabına giriş yapıldı.`);
    fetchListings();
  };

  const handleLogout = () => {
    if (token) {
      fetch('/api/auth/logout', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      }).catch(() => {});
    }
    localStorage.removeItem(TOKEN_KEY);
    setToken(null);
    setCurrentUser(null);
    showToast('info', 'Oturum kapatıldı.');
  };

  // Fetch listings from backend
  const fetchListings = useCallback(async () => {
    try {
      setIsLoadingListings(true);
      const url = selectedGame === 'ALL' ? '/api/listings' : `/api/listings?game=${encodeURIComponent(selectedGame)}`;
      const res = await fetch(url);
      if (res.ok) {
        const data = await res.json();
        setListings(data.listings || []);
      }
    } catch (err) {
      console.error('Error fetching listings:', err);
    } finally {
      setIsLoadingListings(false);
    }
  }, [selectedGame]);

  useEffect(() => {
    fetchListings();
  }, [fetchListings]);

  const handleListingCreated = (newListing: Listing) => {
    setListings((prev) => [newListing, ...prev]);
    showToast('success', `"${newListing.title}" ilanınız başarıyla vitrinde yayınlandı!`);
  };

  // Filter listings
  const filteredListings = listings.filter((l) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    const matchesTitle = l.title.toLowerCase().includes(q);
    const matchesOwner = l.ownerUsername.toLowerCase().includes(q) || l.ownerDiscordTag.toLowerCase().includes(q);
    const matchesOffered = l.offeredItemsText.toLowerCase().includes(q);
    const matchesLooking = l.lookingForText.toLowerCase().includes(q);
    return matchesTitle || matchesOwner || matchesOffered || matchesLooking;
  });

  return (
    <div className="relative min-h-screen bg-zinc-950 text-zinc-100 flex flex-col font-sans selection:bg-purple-600 selection:text-white">
      {/* Live Background GIF: https://files.catbox.moe/k3uuiw.gif */}
      <LiveBackground />

      {/* Toast Bildirimi */}
      {toastMessage && (
        <div className="fixed top-4 right-4 z-50 animate-in slide-in-from-top-4 duration-200">
          <div
            className={`px-4 py-3 rounded-2xl shadow-2xl border flex items-center gap-3 text-sm font-medium backdrop-blur-md ${
              toastMessage.type === 'success'
                ? 'bg-emerald-950/90 text-emerald-200 border-emerald-500/40'
                : toastMessage.type === 'alert'
                ? 'bg-amber-950/90 text-amber-200 border-amber-500/40'
                : toastMessage.type === 'error'
                ? 'bg-red-950/90 text-red-200 border-red-500/40'
                : 'bg-zinc-900/95 text-zinc-200 border-zinc-700'
            }`}
          >
            {toastMessage.type === 'success' ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            ) : (
              <AlertCircle className="w-5 h-5 text-amber-400 shrink-0" />
            )}
            <span>{toastMessage.text}</span>
          </div>
        </div>
      )}

      {/* Main Navbar */}
      <Navbar
        selectedGame={selectedGame}
        onSelectGame={setSelectedGame}
        listingsCount={listings.length}
        currentUser={currentUser}
        onOpenAuth={() => setIsAuthOpen(true)}
        onOpenCreateListing={() => setIsCreateListingOpen(true)}
        onLogout={handleLogout}
      />

      {/* Hero / Tanıtım Banner'ı */}
      <section className="relative z-10 border-b border-zinc-900/80 bg-gradient-to-b from-purple-950/30 via-zinc-950/80 to-zinc-950 py-8 sm:py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
            
            {/* Marka & Değer Önerisi */}
            <div className="max-w-2xl space-y-3">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/30 text-purple-300 text-xs font-bold tracking-wide">
                <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                <span>ROBLOX ADOPT ME! & MM2 GENEL İLAN PAZARI</span>
              </div>

              <h1 className="text-2xl sm:text-4xl font-black text-white tracking-tight">
                İlanını Ver, Discord'dan Anlaş. <br className="hidden sm:inline" />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-indigo-300 to-emerald-400">
                  Özgür ve Hızlı Roblox İlan Vitrini.
                </span>
              </h1>

              <p className="text-sm text-zinc-400 leading-relaxed">
                Adopt Me! petleri ve MM2 eşyaları için ilanınızı özgürce oluşturun. İlan sahibinin Discord etiketini kopyalayarak doğrudan Discord üzerinden anlaşın.
              </p>

              <div className="pt-1 flex flex-wrap items-center gap-2.5">
                <button
                  onClick={currentUser ? () => setIsCreateListingOpen(true) : () => setIsAuthOpen(true)}
                  className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-purple-600/30 transition-all cursor-pointer"
                >
                  <PlusCircle className="w-4 h-4" />
                  <span>📢 Hemen İlan Ver</span>
                </button>
              </div>
            </div>

            {/* Güvenlik & Özellik Rozetleri (Sağ paneldeki webhook yazısı tamamen temizlendi) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 w-full lg:w-auto shrink-0 text-xs">
              <div className="bg-zinc-900/90 border border-zinc-800 p-3 rounded-xl flex items-center gap-3">
                <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
                <div>
                  <div className="font-bold text-white">Zorunlu Discord Bağlantısı</div>
                  <div className="text-[10px] text-zinc-400">Her ilanda doğrulanmış etiket</div>
                </div>
              </div>

              <div className="bg-zinc-900/90 border border-zinc-800 p-3 rounded-xl flex items-center gap-3">
                <MessageCircle className="w-5 h-5 text-purple-400 shrink-0" />
                <div>
                  <div className="font-bold text-white">Discord ile İletişim</div>
                  <div className="text-[10px] text-zinc-400">Tek tıkla kopyala ve anlaş</div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* Main Content Area: İlan Pazarı Vitrini */}
      <main className="relative z-10 flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 w-full space-y-6">
        
        {/* Arama Çubuğu */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-zinc-900/80 p-3 sm:p-4 rounded-2xl border border-zinc-800 backdrop-blur-md">
          <div className="flex items-center gap-2 text-xs font-bold text-zinc-300">
            <Flame className="w-4 h-4 text-amber-400" />
            <span>
              {selectedGame === 'ALL' ? 'Tüm Güncel İlanlar' : `${selectedGame} İlanları`} ({filteredListings.length})
            </span>
          </div>

          {/* Search Input */}
          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="İlan başlığı, eşya veya Discord ara..."
              className="w-full bg-zinc-950 border border-zinc-700/80 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-purple-500 transition-colors"
            />
          </div>
        </div>

        {/* İlanlar Grid'i (Sadece ilan kartları) */}
        {isLoadingListings ? (
          <div className="py-20 flex flex-col items-center justify-center text-zinc-500 space-y-3">
            <div className="w-8 h-8 border-2 border-purple-500 border-t-transparent rounded-full animate-spin" />
            <span className="text-sm font-medium">İlanlar yükleniyor...</span>
          </div>
        ) : filteredListings.length === 0 ? (
          <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-10 text-center space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-zinc-950 border border-zinc-800 flex items-center justify-center mx-auto text-zinc-500">
              <Layers className="w-6 h-6" />
            </div>
            <h3 className="text-sm font-bold text-white">Henüz İlan Bulunmuyor</h3>
            <p className="text-xs text-zinc-400 max-w-md mx-auto">
              Sitede hiçbir bot veya sahte ilan yoktur. İlk gerçek ilanı vererek pazar vitrininde yerinizi alın!
            </p>
            <button
              onClick={currentUser ? () => setIsCreateListingOpen(true) : () => setIsAuthOpen(true)}
              className="py-2.5 px-4 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs inline-flex items-center gap-2 shadow-md cursor-pointer"
            >
              <PlusCircle className="w-4 h-4" />
              <span>İlk İlanı Siz Verin</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredListings.map((listing) => (
              <ListingCard
                key={listing.id}
                listing={listing}
              />
            ))}
          </div>
        )}

      </main>

      {/* Auth Modal */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        onAuthSuccess={handleAuthSuccess}
      />

      {/* Create Listing Modal */}
      {currentUser && token && (
        <CreateListingModal
          isOpen={isCreateListingOpen}
          onClose={() => setIsCreateListingOpen(false)}
          currentUser={currentUser}
          token={token}
          onListingCreated={handleListingCreated}
        />
      )}
    </div>
  );
}
