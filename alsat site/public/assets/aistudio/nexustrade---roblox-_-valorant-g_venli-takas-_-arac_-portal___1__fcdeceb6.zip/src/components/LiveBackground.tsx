import React from 'react';

/**
 * LiveBackground Component
 * Arka planda tam ekran kaplayan hareketli GIF: https://files.catbox.moe/k3uuiw.gif
 * Hem harici link hem de yerel yedek (/assets/background.gif) desteklenir.
 * Üzerine atılan optimize edilmiş koyu filtre (overlay) sayesinde yazıların ve kartların
 * okunabilirliği maksimum düzeyde korunur.
 */
export const LiveBackground: React.FC = () => {
  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden" aria-hidden="true">
      {/* Hareketli GIF Arka Plan Katmanı */}
      <img
        src="https://files.catbox.moe/k3uuiw.gif"
        alt="Live Background"
        className="absolute inset-0 w-full h-full object-cover object-center filter brightness-[0.6] contrast-[1.1] scale-105 transform motion-safe:transition-all"
        onError={(e: any) => {
          e.currentTarget.src = '/assets/background.gif';
        }}
      />

      {/* Saydam Koyu Overlay Katmanları (Yazı okunabilirliği için) */}
      <div className="absolute inset-0 bg-zinc-950/75 backdrop-blur-[2px]" />
      <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/60 to-zinc-950/80" />
      <div className="absolute inset-0 bg-radial from-transparent via-zinc-950/40 to-zinc-950/90" />
    </div>
  );
};
