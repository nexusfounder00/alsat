import React, { useState } from 'react';
import { ShieldCheck, User as UserIcon, Lock, Hash, AlertCircle, ArrowRight } from 'lucide-react';
import { AuthResponse } from '../types/auth';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAuthSuccess: (data: AuthResponse) => void;
}

// Zorunlu Kullanıcı Adı Kuralı: 3-20 karakter, sadece harf, rakam ve alt çizgi (_)
export const USERNAME_REGEX = /^[a-zA-Z0-9_]{3,20}$/;

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, onAuthSuccess }) => {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [discordTag, setDiscordTag] = useState('');

  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    const cleanUsername = username.trim();

    // 1. Strict Regex Kontrolü
    if (!USERNAME_REGEX.test(cleanUsername)) {
      setErrorMsg('Kullanıcı adı sadece harf, rakam ve alt çizgi (_) içerebilir (3-20 karakter). Rastgele/anlamsız karakter dizileri yasaktır.');
      return;
    }

    // 2. Şifre Kriteri: En az 6 karakter
    if (!password || password.trim().length < 6) {
      setErrorMsg('Şifre alanı zorunludur ve en az 6 karakter uzunluğunda olmalıdır.');
      return;
    }

    // 3. Zorunlu Discord Adı ve Etiketi
    if (mode === 'register') {
      const cleanDiscord = discordTag.trim();
      if (!cleanDiscord || cleanDiscord.length < 3) {
        setErrorMsg('Discord Kullanıcı Adı ve Etiketi KESİNLİKLE ZORUNLUDUR (Örn: @kullaniciadi veya kullaniciadi#1234). Etiket girilmeden kayıt yapılamaz.');
        return;
      }
    }

    setIsLoading(true);

    try {
      const endpoint = mode === 'register' ? '/api/auth/register' : '/api/auth/login';
      const body =
        mode === 'register'
          ? {
              username: cleanUsername,
              password,
              discordTag: discordTag.trim(),
            }
          : {
              username: cleanUsername,
              password,
            };

      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'İşlem başarısız oldu.');
      }

      onAuthSuccess(data);
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'Bir hata oluştu.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md">
      <div className="bg-zinc-900 border border-zinc-700/80 rounded-2xl w-full max-w-md shadow-2xl overflow-hidden p-6 animate-in fade-in zoom-in-95 duration-150">
        
        {/* Başlık ve Kapat Butonu */}
        <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-purple-600/20 border border-purple-500/40 flex items-center justify-center text-purple-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-black text-white">
                {mode === 'login' ? 'Giriş Yap' : 'Kayıt Ol'}
              </h2>
              <p className="text-xs text-zinc-400">Alsat İlan Pazarı Hesabınız</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-zinc-400 hover:text-white p-1 text-sm cursor-pointer"
          >
            ✕
          </button>
        </div>

        {/* Tab Geçiş Butonları */}
        <div className="grid grid-cols-2 gap-2 p-1 bg-zinc-950 rounded-xl my-5 border border-zinc-800">
          <button
            type="button"
            onClick={() => { setMode('login'); setErrorMsg(null); }}
            className={`py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
              mode === 'login'
                ? 'bg-zinc-800 text-white shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Giriş Yap
          </button>
          <button
            type="button"
            onClick={() => { setMode('register'); setErrorMsg(null); }}
            className={`py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
              mode === 'register'
                ? 'bg-zinc-800 text-white shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Kayıt Ol
          </button>
        </div>

        {/* Hata Mesajı */}
        {errorMsg && (
          <div className="p-3 mb-4 bg-red-950/70 border border-red-500/40 text-red-200 text-xs rounded-xl flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Form Alanı (Sadece Manuel Girdi) */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-zinc-300 mb-1.5">
              Kullanıcı Adı <span className="text-purple-400">*</span>
            </label>
            <div className="relative">
              <UserIcon className="w-4 h-4 text-zinc-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Örn: ahmet_oyuncu"
                className="w-full bg-zinc-950 border border-zinc-700/80 rounded-xl pl-10 pr-3 py-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-purple-500"
              />
            </div>
            <p className="text-[10px] text-zinc-500 mt-1">
              3-20 karakter, sadece harf, rakam ve alt çizgi (_).
            </p>
          </div>

          <div>
            <label className="block text-xs font-bold text-zinc-300 mb-1.5">
              Şifre <span className="text-purple-400">*</span>
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-zinc-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="En az 6 karakter"
                minLength={6}
                className="w-full bg-zinc-950 border border-zinc-700/80 rounded-xl pl-10 pr-3 py-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-purple-500"
              />
            </div>
          </div>

          {mode === 'register' && (
            <div>
              <label className="block text-xs font-bold text-zinc-300 mb-1.5">
                Discord Kullanıcı Adı / Etiketi <span className="text-purple-400">*</span>
              </label>
              <div className="relative">
                <Hash className="w-4 h-4 text-indigo-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  required
                  value={discordTag}
                  onChange={(e) => setDiscordTag(e.target.value)}
                  placeholder="Örn: @kullaniciadi veya mehmet#1234"
                  className="w-full bg-zinc-950 border border-zinc-700/80 rounded-xl pl-10 pr-3 py-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-purple-500"
                />
              </div>
              <p className="text-[10px] text-zinc-500 mt-1">
                İlanlarınıza ilgi duyan oyuncular size Discord üzerinden bu adresle ulaşır.
              </p>
            </div>
          )}

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-purple-600/30 transition-all cursor-pointer disabled:opacity-50 mt-2"
          >
            {isLoading ? (
              <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <>
                <span>{mode === 'login' ? 'Giriş Yap' : 'Kayıt Ol'}</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};
