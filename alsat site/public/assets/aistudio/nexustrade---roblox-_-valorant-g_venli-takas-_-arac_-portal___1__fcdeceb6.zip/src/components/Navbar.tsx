import React from 'react';
import {
  ShieldCheck,
  User as UserIcon,
  LogOut,
  Sparkles,
  LogIn,
  PlusCircle,
} from 'lucide-react';
import { User } from '../types/auth';

interface NavbarProps {
  selectedGame: 'Adopt Me!' | 'MM2' | 'ALL';
  onSelectGame: (game: 'Adopt Me!' | 'MM2' | 'ALL') => void;
  listingsCount: number;
  currentUser: User | null;
  onOpenAuth: () => void;
  onOpenCreateListing: () => void;
  onLogout: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  selectedGame,
  onSelectGame,
  listingsCount,
  currentUser,
  onOpenAuth,
  onOpenCreateListing,
  onLogout,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-zinc-950/90 backdrop-blur-md border-b border-zinc-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-3">
          
          {/* Logo & Brand: Alsat */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => onSelectGame('ALL')}
              className="flex items-center gap-2.5 text-left group focus:outline-none cursor-pointer"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-emerald-400 p-0.5 shadow-lg shadow-purple-600/30 group-hover:scale-105 transition-transform">
                <div className="w-full h-full bg-zinc-950 rounded-[10px] flex items-center justify-center">
                  <span className="font-black text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-emerald-400 text-lg">
                    A
                  </span>
                </div>
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="font-black text-xl tracking-tight text-white group-hover:text-purple-300 transition-colors">
                    Alsat
                  </span>
                  <span className="text-[10px] uppercase font-extrabold tracking-wider px-1.5 py-0.5 rounded bg-purple-500/10 text-purple-400 border border-purple-500/25">
                    İLAN PAZARI
                  </span>
                </div>
                <p className="text-[11px] text-zinc-400 font-medium hidden sm:block">
                  Roblox Adopt Me! & MM2 İlan Portalı
                </p>
              </div>
            </button>
          </div>

          {/* Oyun Seçim Butonları */}
          <nav className="hidden md:flex items-center gap-1 bg-zinc-900/90 p-1 rounded-xl border border-zinc-800">
            <button
              onClick={() => onSelectGame('ALL')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                selectedGame === 'ALL'
                  ? 'bg-zinc-800 text-white shadow-sm'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              Tüm İlanlar ({listingsCount})
            </button>
            <button
              onClick={() => onSelectGame('MM2')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-all cursor-pointer ${
                selectedGame === 'MM2'
                  ? 'bg-rose-950/70 text-rose-300 border border-rose-500/40 shadow-sm'
                  : 'text-zinc-400 hover:text-rose-300'
              }`}
            >
              <span>🔪</span> Murder Mystery 2
            </button>
            <button
              onClick={() => onSelectGame('Adopt Me!')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-all cursor-pointer ${
                selectedGame === 'Adopt Me!'
                  ? 'bg-emerald-950/70 text-emerald-300 border border-emerald-500/40 shadow-sm'
                  : 'text-zinc-400 hover:text-emerald-300'
              }`}
            >
              <span>🐾</span> Adopt Me!
            </button>
          </nav>

          {/* Sağ Aksiyon Alanı */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* İlan Ver Butonu */}
            <button
              data-testid="navbar-create-listing-btn"
              onClick={currentUser ? onOpenCreateListing : onOpenAuth}
              className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-purple-600/30 transition-all cursor-pointer"
            >
              <PlusCircle className="w-4 h-4" />
              <span>İlan Ver</span>
            </button>

            {/* Kullanıcı Giriş Durumu */}
            {currentUser ? (
              <div className="flex items-center gap-2">
                <div className="bg-zinc-900 border border-zinc-800 rounded-xl px-2.5 py-1.5 flex items-center gap-2">
                  <div className="w-6 h-6 rounded-lg bg-gradient-to-br from-purple-600 to-indigo-600 flex items-center justify-center text-white text-[10px] font-black">
                    {currentUser.username.charAt(0).toUpperCase()}
                  </div>
                  <div className="hidden sm:block text-left">
                    <div className="text-xs font-bold text-white leading-tight">
                      {currentUser.username}
                    </div>
                    <div className="text-[10px] text-indigo-400 font-mono leading-tight">
                      {currentUser.discordTag}
                    </div>
                  </div>
                </div>

                <button
                  onClick={onLogout}
                  className="p-2 rounded-xl text-zinc-400 hover:text-red-400 hover:bg-zinc-900 border border-transparent hover:border-zinc-800 transition-colors cursor-pointer"
                  title="Çıkış Yap"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={onOpenAuth}
                className="py-1.5 px-3.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs sm:text-sm shadow-md shadow-purple-600/30 transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <LogIn className="w-4 h-4" />
                <span>Giriş Yap</span>
              </button>
            )}
          </div>

        </div>

        {/* Mobil Oyun Seçimi */}
        <div className="md:hidden flex items-center gap-1 pb-3 overflow-x-auto text-xs">
          <button
            onClick={() => onSelectGame('ALL')}
            className={`px-3 py-1 rounded-lg shrink-0 font-medium ${
              selectedGame === 'ALL'
                ? 'bg-zinc-800 text-white'
                : 'text-zinc-400'
            }`}
          >
            Tüm İlanlar ({listingsCount})
          </button>
          <button
            onClick={() => onSelectGame('MM2')}
            className={`px-3 py-1 rounded-lg shrink-0 font-medium flex items-center gap-1 ${
              selectedGame === 'MM2'
                ? 'bg-rose-950/70 text-rose-300 border border-rose-500/40'
                : 'text-zinc-400'
            }`}
          >
            🔪 MM2
          </button>
          <button
            onClick={() => onSelectGame('Adopt Me!')}
            className={`px-3 py-1 rounded-lg shrink-0 font-medium flex items-center gap-1 ${
              selectedGame === 'Adopt Me!'
                ? 'bg-emerald-950/70 text-emerald-300 border border-emerald-500/40'
                : 'text-zinc-400'
            }`}
          >
            🐾 Adopt Me!
          </button>
        </div>

      </div>
    </header>
  );
};
