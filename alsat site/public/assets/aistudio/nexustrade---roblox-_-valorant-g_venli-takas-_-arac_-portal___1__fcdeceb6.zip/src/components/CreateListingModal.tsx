import React, { useState, useRef } from 'react';
import {
  PlusCircle,
  X,
  AlertCircle,
  Sparkles,
  ShieldAlert,
  Upload,
  Image as ImageIcon,
  Check,
} from 'lucide-react';
import { User } from '../types/auth';
import { Listing } from '../types/listing';

interface CreateListingModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
  token: string;
  onListingCreated: (newListing: Listing) => void;
}

export const CreateListingModal: React.FC<CreateListingModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  token,
  onListingCreated,
}) => {
  const [game, setGame] = useState<'Adopt Me!' | 'MM2'>('MM2');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [offeredItemsText, setOfferedItemsText] = useState('');
  const [lookingForText, setLookingForText] = useState('');
  
  // Dosyadan fotoğraf yükleme state'i (URL değil, gerçek dosya)
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [filePreview, setFilePreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setErrorMsg('Lütfen geçerli bir görsel dosyası (PNG, JPG, WEBP) seçin.');
      return;
    }

    if (file.size > 8 * 1024 * 1024) {
      setErrorMsg('Görsel boyutu en fazla 8MB olabilir.');
      return;
    }

    setSelectedFile(file);
    const reader = new FileReader();
    reader.onloadend = () => {
      setFilePreview(reader.result as string);
    };
    reader.readAsDataURL(file);
    setErrorMsg(null);
  };

  const handleRemoveFile = () => {
    setSelectedFile(null);
    setFilePreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (title.trim().length < 4) {
      setErrorMsg('İlan başlığı en az 4 karakter olmalıdır.');
      return;
    }

    if (!offeredItemsText.trim()) {
      setErrorMsg('Lütfen verdiğiniz / sunduğunuz eşyaları veya petleri yazın.');
      return;
    }

    if (!lookingForText.trim()) {
      setErrorMsg('Lütfen aradığınız / istediğiniz şeyleri yazın.');
      return;
    }

    if (description.trim().length < 6) {
      setErrorMsg('İlan açıklaması en az 6 karakter olmalıdır.');
      return;
    }

    setIsLoading(true);

    try {
      const res = await fetch('/api/listings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          game,
          title: title.trim(),
          description: description.trim(),
          offeredItemsText: offeredItemsText.trim(),
          lookingForText: lookingForText.trim(),
          imageBase64: filePreview || undefined,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'İlan oluşturulamadı.');
      }

      onListingCreated(data.listing);
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'İlan kaydedilirken bir hata oluştu.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div className="bg-zinc-900 border border-zinc-700/80 rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden my-auto flex flex-col max-h-[92vh] animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-zinc-800 bg-zinc-950 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-purple-600 to-emerald-400 p-0.5 shadow-md">
              <div className="w-full h-full bg-zinc-950 rounded-[10px] flex items-center justify-center text-purple-400">
                <PlusCircle className="w-5 h-5" />
              </div>
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black text-white">
                Yeni İlan Ver
              </h2>
              <p className="text-xs text-zinc-400">
                İlanınız anında vitrinde listelenir ve oyuncular Discord'dan ulaşır.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Bilgilendirme Notu */}
        <div className="bg-purple-950/30 border-b border-purple-500/20 px-4 py-2.5 text-xs text-purple-300 flex items-center gap-2">
          <ShieldAlert className="w-4 h-4 text-purple-400 shrink-0" />
          <span>
            İlanınıza ilgi duyan oyuncular Discord üzerinden (<strong>{currentUser.discordTag}</strong>) sizinle iletişime geçecektir.
          </span>
        </div>

        {/* Hata Bildirimi */}
        {errorMsg && (
          <div className="p-3 bg-red-950/70 border-b border-red-500/40 text-red-200 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Serbest İlan Verme Formu */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-6 overflow-y-auto space-y-4 text-xs">
          
          {/* 1. Oyun Kategorisi Seçimi */}
          <div>
            <label className="block text-zinc-300 font-bold mb-1.5">
              Oyun Kategorisi <span className="text-purple-400">*</span>
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setGame('MM2')}
                className={`py-2.5 px-3 rounded-xl font-bold flex items-center justify-center gap-2 border transition-all cursor-pointer ${
                  game === 'MM2'
                    ? 'bg-rose-950/60 text-rose-300 border-rose-500/60 shadow-sm'
                    : 'bg-zinc-950 text-zinc-400 border-zinc-800 hover:bg-zinc-850'
                }`}
              >
                <span>🔪</span> Murder Mystery 2 (MM2)
              </button>
              <button
                type="button"
                onClick={() => setGame('Adopt Me!')}
                className={`py-2.5 px-3 rounded-xl font-bold flex items-center justify-center gap-2 border transition-all cursor-pointer ${
                  game === 'Adopt Me!'
                    ? 'bg-emerald-950/60 text-emerald-300 border-emerald-500/60 shadow-sm'
                    : 'bg-zinc-950 text-zinc-400 border-zinc-800 hover:bg-zinc-850'
                }`}
              >
                <span>🐾</span> Adopt Me!
              </button>
            </div>
          </div>

          {/* 2. İlan Başlığı */}
          <div>
            <label className="block text-zinc-300 font-bold mb-1">
              İlan Başlığı <span className="text-purple-400">*</span>
            </label>
            <input
              data-testid="listing-title-input"
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder={game === 'MM2' ? 'Örn: Harvester & Corrupt Set Satılık • Teklif Bekliyorum' : 'Örn: FR Shadow Dragon & Neon Owl Satılık'}
              className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-purple-500"
            />
          </div>

          {/* 3. Verdiğim / Sunduğum Şey (Serbest Metin) */}
          <div>
            <label className="block text-zinc-300 font-bold mb-1">
              Verdiğim / Sunduğum Şey (Eşya, Pet vb.) <span className="text-purple-400">*</span>
            </label>
            <input
              data-testid="listing-offered-input"
              type="text"
              required
              value={offeredItemsText}
              onChange={(e) => setOfferedItemsText(e.target.value)}
              placeholder={game === 'MM2' ? 'Örn: Corrupt, Harvester, Luger, Darkbringer...' : 'Örn: FR Shadow Dragon, Neon Owl, Mega Cow...'}
              className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-purple-500"
            />
            <p className="text-[10px] text-zinc-500 mt-1">İlanınızda vermek istediğiniz eşyaları veya petleri serbestçe yazabilirsiniz.</p>
          </div>

          {/* 4. Aradığım / İstediğim Şey (Serbest Metin) */}
          <div>
            <label className="block text-zinc-300 font-bold mb-1">
              Aradığım / İstediğim Şey <span className="text-purple-400">*</span>
            </label>
            <input
              data-testid="listing-looking-input"
              type="text"
              required
              value={lookingForText}
              onChange={(e) => setLookingForText(e.target.value)}
              placeholder="Örn: Bat Dragon + Frost Dragon veya iyi MM2 teklifleri..."
              className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-purple-500"
            />
          </div>

          {/* 5. CİHAZDAN FOTOĞRAF YÜKLEME ALANI (GERÇEK DOSYA SEÇİCİ) */}
          <div>
            <label className="block text-zinc-300 font-bold mb-1.5 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <ImageIcon className="w-3.5 h-3.5 text-purple-400" />
                <span>İlan Fotoğrafı Ekle (Cihazınızdan Seçin)</span>
              </span>
              <span className="text-[10px] text-zinc-500 font-normal">PNG, JPG, WEBP (Max 8MB)</span>
            </label>

            {/* Gizli Dosya Girişi */}
            <input
              data-testid="listing-file-input"
              type="file"
              ref={fileInputRef}
              accept="image/*"
              onChange={handleFileChange}
              className="hidden"
            />

            {!filePreview ? (
              <div
                onClick={() => fileInputRef.current?.click()}
                className="w-full border-2 border-dashed border-zinc-750 hover:border-purple-500 bg-zinc-950/70 hover:bg-zinc-950 rounded-2xl p-6 flex flex-col items-center justify-center gap-2 cursor-pointer transition-all group"
              >
                <div className="w-12 h-12 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-400 group-hover:text-purple-400 group-hover:scale-105 transition-all">
                  <Upload className="w-6 h-6" />
                </div>
                <div className="text-center">
                  <span className="text-xs font-bold text-white group-hover:text-purple-300">
                    Fotoğraf Yüklemek İçin Tıklayın
                  </span>
                  <p className="text-[11px] text-zinc-500 mt-0.5">
                    Oyun içi ekran görüntüsünü veya eşya kanıt fotoğrafını cihazınızdan seçin
                  </p>
                </div>
              </div>
            ) : (
              <div className="relative rounded-2xl overflow-hidden border border-zinc-700 bg-zinc-950 p-2 flex items-center gap-3">
                <div className="w-20 h-20 rounded-xl overflow-hidden bg-zinc-900 shrink-0 border border-zinc-800 flex items-center justify-center">
                  <img
                    src={filePreview}
                    alt="Yüklenen Görsel Önizleme"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5 text-emerald-400 text-xs font-bold">
                    <Check className="w-4 h-4" />
                    <span>Fotoğraf Başarıyla Seçildi</span>
                  </div>
                  <p className="text-[11px] text-zinc-300 truncate mt-0.5">
                    {selectedFile?.name}
                  </p>
                  <p className="text-[10px] text-zinc-500">
                    {selectedFile ? `${(selectedFile.size / 1024).toFixed(1)} KB` : ''}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={handleRemoveFile}
                  className="p-2 rounded-xl bg-zinc-900 hover:bg-red-950/60 border border-zinc-800 hover:border-red-500/50 text-zinc-400 hover:text-red-300 transition-colors cursor-pointer mr-1"
                  title="Fotoğrafı kaldır"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>

          {/* 6. İlan Açıklaması */}
          <div>
            <label className="block text-zinc-300 font-bold mb-1">
              İlan Açıklaması & İletişim Notları <span className="text-purple-400">*</span>
            </label>
            <textarea
              data-testid="listing-desc-input"
              required
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Discord üzerinden mesaj atabilirsiniz, akşam saatlerinde oyunda aktifim..."
              className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-purple-500 resize-none"
            />
          </div>

          {/* Gönder Butonu */}
          <div className="pt-2">
            <button
              data-testid="listing-submit-btn"
              type="submit"
              disabled={isLoading}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-purple-600/30 transition-all cursor-pointer disabled:opacity-50"
            >
              {isLoading ? (
                <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <PlusCircle className="w-4 h-4" />
                  <span>İlanı Pazarda Yayınla</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
