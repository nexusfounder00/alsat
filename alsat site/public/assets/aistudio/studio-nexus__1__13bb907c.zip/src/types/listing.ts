export interface Listing {
  id: string;
  ownerId: string;
  ownerUsername: string;
  ownerDiscordTag: string;
  game: 'MM2' | 'Adopt Me!';
  title: string;
  description: string;
  offeredItemsText: string; // Kullanıcının serbestçe yazdığı sunduğu şeyler
  lookingForText: string;   // Kullanıcının serbestçe yazdığı aradığı/istediği şeyler
  imageUrl?: string;        // Kullanıcının yüklediği görselin yerel sunucu yolu (/uploads/...)
  status: 'ACTIVE' | 'CLOSED';
  createdAt: string;
}
