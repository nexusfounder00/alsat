export interface User {
  id: string;
  username: string;
  discordTag: string; // Kullanıcının Discord üzerinden ulaşılabileceği adı
  role?: 'ADMIN' | 'USER';
  isAdmin?: boolean;
  isBanned?: boolean;
  createdAt: string;
}

export interface AuthResponse {
  success: boolean;
  user: User;
  token: string;
  message?: string;
}
