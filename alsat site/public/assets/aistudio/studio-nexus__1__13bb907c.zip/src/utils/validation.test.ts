import test from 'node:test';
import assert from 'node:assert/strict';
import {
  validateUsername,
  validatePassword,
  validatePasswordConfirm,
  validateDiscordTag,
  validateListingInput,
  calculateRemainingCooldown,
  USERNAME_REGEX,
} from './validation';

test('USERNAME_REGEX accepts valid names up to 10 characters', () => {
  assert.equal(USERNAME_REGEX.test('ahmet_23'), true);
  assert.equal(USERNAME_REGEX.test('proGamer'), true);
  assert.equal(USERNAME_REGEX.test('mm2_king'), true);
  assert.equal(USERNAME_REGEX.test('Roblox_1'), true);
  assert.equal(USERNAME_REGEX.test('1234567890'), true); // 10 chars
});

test('USERNAME_REGEX rejects names over 10 characters or with tags', () => {
  assert.equal(USERNAME_REGEX.test('ab'), false); // too short (<3)
  assert.equal(USERNAME_REGEX.test('12345678901'), false); // 11 chars (>10)
  assert.equal(USERNAME_REGEX.test('oyuncu#1234'), false); // contains # tag
  assert.equal(USERNAME_REGEX.test('user@name'), false); // invalid character @
  assert.equal(USERNAME_REGEX.test('user-name'), false); // hyphen not in regex
  assert.equal(USERNAME_REGEX.test(''), false);
});

test('validateUsername enforces max 10 chars, rejects # tag and empty inputs', () => {
  assert.equal(validateUsername('').isValid, false);
  assert.equal(validateUsername(null).isValid, false);
  assert.equal(validateUsername('oyuncu#1234').isValid, false); // Tag rejected
  assert.equal(validateUsername('toolongname1').isValid, false); // >10 chars
  assert.equal(validateUsername('ads').isValid, false); // blocked spam
  assert.equal(validateUsername('valid_name').isValid, true); // 10 chars max
});

test('validatePassword requires at least 6 characters', () => {
  assert.equal(validatePassword('12345').isValid, false);
  assert.equal(validatePassword('123456').isValid, true);
  assert.equal(validatePassword('secure_password').isValid, true);
});

test('validateListingInput checks all mandatory listing fields', () => {
  const valid = {
    game: 'MM2',
    title: 'Harvester Satılık',
    offeredItemsText: 'Harvester',
    lookingForText: 'Corrupt Set',
    description: 'Discord üzerinden mesaj atabilirsiniz',
  };
  assert.equal(validateListingInput(valid).isValid, true);
  assert.equal(validateListingInput({ ...valid, title: 'ab' }).isValid, false);
  assert.equal(validateListingInput({ ...valid, game: 'Fortnite' }).isValid, false);
});

test('calculateRemainingCooldown correctly calculates seconds', () => {
  const now = 100000;
  const remaining = calculateRemainingCooldown(now - 30000, now, 60000);
  assert.equal(remaining, 30);
  const expired = calculateRemainingCooldown(now - 60000, now, 60000);
  assert.equal(expired, 0);
});

test('validatePasswordConfirm correctly checks matching passwords', () => {
  assert.equal(validatePasswordConfirm('gizli123', 'gizli123').isValid, true);
  assert.equal(validatePasswordConfirm('gizli123', 'farkli123').isValid, false);
  assert.equal(validatePasswordConfirm('gizli123', '').isValid, false);
});
