/**
 * Validation utilities for Alsat Marketplace
 * Strictly disallows random string generation, validates manual name/username (max 10 chars, no tag),
 * password, and listings.
 */

// Sadece isim: maksimum 10 karakter (3-10 karakter), kesinlikle etiket (#) yok
export const USERNAME_REGEX = /^[a-zA-Z0-9_]{3,10}$/;

export interface ValidationResult {
  isValid: boolean;
  error?: string;
}

// Bilinen anlamsız/klavye kırma veya rastgele girilen 3-4 harfli spam isimler
const BLOCKED_NAMES = new Set([
  'ads',
  'asd',
  'asdf',
  'qwe',
  'qwer',
  'zxc',
  'zxcv',
  'abc',
  'abcd',
  'xxx',
  'test',
  'null',
  'undefined',
  'admin',
]);

export function validateUsername(username: unknown): ValidationResult {
  if (!username || typeof username !== 'string') {
    return { isValid: false, error: 'Discord ismi zorunludur.' };
  }
  const clean = username.trim().replace(/^@/, '');

  if (clean.includes('#')) {
    return {
      isValid: false,
      error: 'Etiket (#) kullanılmamaktadır. Lütfen sadece Discord isminizi giriniz (en fazla 10 karakter).',
    };
  }

  if (clean.length < 3 || clean.length > 10) {
    return {
      isValid: false,
      error: 'Discord ismi en az 3, en fazla 10 karakter olmalıdır (Örn: oyuncu).',
    };
  }

  if (!USERNAME_REGEX.test(clean)) {
    return {
      isValid: false,
      error: 'Discord ismi sadece harf, rakam ve alt çizgi (_) içerebilir (en fazla 10 karakter).',
    };
  }

  if (BLOCKED_NAMES.has(clean.toLowerCase())) {
    return {
      isValid: false,
      error: `'${clean}' gibi anlamsız isimler kabul edilmez. Lütfen geçerli Discord isminizi girin.`,
    };
  }

  // Tekrarlayan karakter dizisi kontrolü (aaaa, 1111)
  if (/(.)\1{3,}/.test(clean)) {
    return {
      isValid: false,
      error: 'Tekrarlayan karakterler Discord ismi olarak kabul edilmez.',
    };
  }

  return { isValid: true };
}

export function validateDiscordTag(discordTag: unknown): ValidationResult {
  // Kullanıcı talebi doğrultusunda etiket kaldırıldı; doğrudan isim doğrulamasına yönlendirilir
  return validateUsername(discordTag);
}

export function validatePassword(password: unknown): ValidationResult {
  if (!password || typeof password !== 'string' || password.trim().length < 6) {
    return {
      isValid: false,
      error: 'Şifre alanı zorunludur ve en az 6 karakter olmalıdır.',
    };
  }
  return { isValid: true };
}

export function validatePasswordConfirm(password: unknown, passwordConfirm: unknown): ValidationResult {
  if (!passwordConfirm || typeof passwordConfirm !== 'string') {
    return {
      isValid: false,
      error: 'Lütfen şifre tekrarı alanını doldurun.',
    };
  }
  if (password !== passwordConfirm) {
    return {
      isValid: false,
      error: 'Girdiğiniz şifreler birbiriyle eşleşmiyor.',
    };
  }
  return { isValid: true };
}

export interface ListingInput {
  game: string;
  title: string;
  description: string;
  offeredItemsText: string;
  lookingForText: string;
}

export function validateListingInput(input: Partial<ListingInput>): ValidationResult {
  if (!input.game || (input.game !== 'MM2' && input.game !== 'Adopt Me!')) {
    return { isValid: false, error: 'Lütfen geçerli bir oyun seçin (MM2 veya Adopt Me!).' };
  }
  if (!input.title || typeof input.title !== 'string' || input.title.trim().length < 4) {
    return { isValid: false, error: 'İlan başlığı en az 4 karakter olmalıdır.' };
  }
  if (!input.offeredItemsText || typeof input.offeredItemsText !== 'string' || input.offeredItemsText.trim().length === 0) {
    return { isValid: false, error: 'Lütfen verdiğiniz / sunduğunuz şeyleri yazın.' };
  }
  if (!input.lookingForText || typeof input.lookingForText !== 'string' || input.lookingForText.trim().length === 0) {
    return { isValid: false, error: 'Lütfen aradığınız / istediğiniz şeyleri yazın.' };
  }
  if (!input.description || typeof input.description !== 'string' || input.description.trim().length < 6) {
    return { isValid: false, error: 'İlan açıklaması en az 6 karakter olmalıdır.' };
  }
  return { isValid: true };
}

export function calculateRemainingCooldown(lastListingTimestamp: number, now: number, cooldownMs = 60000): number {
  const elapsed = now - lastListingTimestamp;
  if (elapsed >= cooldownMs) return 0;
  return Math.ceil((cooldownMs - elapsed) / 1000);
}
