import React, { useState, useEffect, useCallback } from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  Users,
  Layers,
  Trash2,
  Ban,
  CheckCircle,
  AlertTriangle,
  RefreshCw,
  Search,
  Megaphone,
  Send,
  Eye,
  LogOut,
  Sliders,
  Cpu,
  Activity,
  ArrowLeft,
  Sparkles,
  Clock,
  Check,
} from 'lucide-react';
import { User } from '../types/auth';
import { Listing } from '../types/listing';

interface AdminStats {
  totalUsers: number;
  totalListings: number;
  mm2Count: number;
  adoptMeCount: number;
  bannedCount: number;
  totalCaptchaPassed: number;
  totalCaptchaFailed: number;
  uptimeSeconds: number;
  memoryUsageMb: number;
}

interface SecurityLog {
  id: string;
  timestamp: string;
  action: 'CHALLENGE_CREATED' | 'CHALLENGE_PASSED' | 'CHALLENGE_FAILED';
  ip: string;
  details: string;
}

interface AdminUserRow {
  id: string;
  username: string;
  discordTag: string;
  role: string;
  isAdmin: boolean;
  isBanned: boolean;
  createdAt: string;
  listingsCount: number;
}

interface AdminPanelProps {
  currentUser: User;
  token: string;
  onBackToMarketplace: () => void;
  onLogout: () => void;
  onSelectListingDetail?: (listing: Listing) => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  currentUser,
  token,
  onBackToMarketplace,
  onLogout,
  onSelectListingDetail,
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'listings' | 'users' | 'security' | 'webhook'>('overview');

  // Overview data
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [securityLogs, setSecurityLogs] = useState<SecurityLog[]>([]);
  const [announcementText, setAnnouncementText] = useState('');
  const [isUpdatingAnnouncement, setIsUpdatingAnnouncement] = useState(false);
  const [announcementSuccess, setAnnouncementSuccess] = useState(false);

  // Users data
  const [users, setUsers] = useState<AdminUserRow[]>([]);
  const [usersSearch, setUsersSearch] = useState('');
  const [isLoadingUsers, setIsLoadingUsers] = useState(false);

  // Listings data
  const [listings, setListings] = useState<Listing[]>([]);
  const [listingsSearch, setListingsSearch] = useState('');
  const [selectedGameFilter, setSelectedGameFilter] = useState<'ALL' | 'MM2' | 'Adopt Me!'>('ALL');
  const [isLoadingListings, setIsLoadingListings] = useState(false);

  // Webhook Test
  const [testWebhookMsg, setTestWebhookMsg] = useState('');
  const [isSendingWebhook, setIsSendingWebhook] = useState(false);
  const [webhookResult, setWebhookResult] = useState<{ success: boolean; text: string } | null>(null);

  // Global alert
  const [actionMessage, setActionMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const notify = (type: 'success' | 'error', text: string) => {
    setActionMessage({ type, text });
    setTimeout(() => {
      setActionMessage((prev) => (prev?.text === text ? null : prev));
    }, 4000);
  };

  // Fetch Overview Stats
  const fetchOverview = useCallback(async () => {
    try {
      const res = await fetch('/api/admin/overview', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setStats(data.stats);
        setSecurityLogs(data.securityLogs || []);
        setAnnouncementText(data.announcement || '');
      }
    } catch (err) {
      console.error('Failed to load admin overview:', err);
    }
  }, [token]);

  // Fetch Users
  const fetchUsers = useCallback(async () => {
    setIsLoadingUsers(true);
    try {
      const res = await fetch('/api/admin/users', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setUsers(data.users || []);
      }
    } catch (err) {
      console.error('Failed to load users:', err);
    } finally {
      setIsLoadingUsers(false);
    }
  }, [token]);

  // Fetch Listings
  const fetchListings = useCallback(async () => {
    setIsLoadingListings(true);
    try {
      const res = await fetch('/api/listings');
      if (res.ok) {
        const data = await res.json();
        setListings(data.listings || []);
      }
    } catch (err) {
      console.error('Failed to load listings:', err);
    } finally {
      setIsLoadingListings(false);
    }
  }, []);

  useEffect(() => {
    fetchOverview();
    fetchUsers();
    fetchListings();
  }, [fetchOverview, fetchUsers, fetchListings]);

  // Toggle Ban
  const handleToggleBan = async (user: AdminUserRow) => {
    if (user.username === '1231321323') {
      notify('error', 'Ana admin hesabı yasaklanamaz!');
      return;
    }
    try {
      const res = await fetch(`/api/admin/users/${user.id}/toggle-ban`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      notify('success', data.message || 'Kullanıcı durumu güncellendi.');
      setUsers((prev) =>
        prev.map((u) => (u.id === user.id ? { ...u, isBanned: !u.isBanned } : u))
      );
      fetchOverview();
    } catch (err: any) {
      notify('error', err.message || 'İşlem başarısız.');
    }
  };

  // Delete User
  const handleDeleteUser = async (user: AdminUserRow) => {
    if (user.username === '1231321323') {
      notify('error', 'Ana admin hesabı silinemez!');
      return;
    }
    if (!window.confirm(`"${user.username}" adlı kullanıcıyı ve tüm ilanlarını silmek istediğinize emin misiniz?`)) {
      return;
    }
    try {
      const res = await fetch(`/api/admin/users/${user.id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      notify('success', data.message || 'Kullanıcı silindi.');
      setUsers((prev) => prev.filter((u) => u.id !== user.id));
      fetchListings();
      fetchOverview();
    } catch (err: any) {
      notify('error', err.message || 'Kullanıcı silinemedi.');
    }
  };

  // Delete Listing
  const handleDeleteListing = async (listingId: string, listingTitle: string) => {
    if (!window.confirm(`"${listingTitle}" ilanını kalıcı olarak silmek istediğinize emin misiniz?`)) {
      return;
    }
    try {
      const res = await fetch(`/api/admin/listings/${listingId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      notify('success', data.message || 'İlan silindi.');
      setListings((prev) => prev.filter((l) => l.id !== listingId));
      fetchOverview();
    } catch (err: any) {
      notify('error', err.message || 'İlan silinemedi.');
    }
  };

  // Update Announcement
  const handleUpdateAnnouncement = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsUpdatingAnnouncement(true);
    try {
      const res = await fetch('/api/admin/announcement', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ announcement: announcementText }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      setAnnouncementSuccess(true);
      notify('success', 'Global sistem duyurusu canlı olarak güncellendi.');
      setTimeout(() => setAnnouncementSuccess(false), 3000);
    } catch (err: any) {
      notify('error', err.message || 'Duyuru güncellenemedi.');
    } finally {
      setIsUpdatingAnnouncement(false);
    }
  };

  // Send Test Webhook
  const handleSendTestWebhook = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSendingWebhook(true);
    setWebhookResult(null);
    try {
      const res = await fetch('/api/admin/test-webhook', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ testMessage: testWebhookMsg }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      setWebhookResult({ success: true, text: data.message || 'Webhook başarıyla gönderildi.' });
      setTestWebhookMsg('');
    } catch (err: any) {
      setWebhookResult({ success: false, text: err.message || 'Webhook hatası oluştu.' });
    } finally {
      setIsSendingWebhook(false);
    }
  };

  // Filtered users
  const filteredUsers = users.filter((u) => {
    if (!usersSearch.trim()) return true;
    const q = usersSearch.toLowerCase();
    return u.username.toLowerCase().includes(q) || u.discordTag.toLowerCase().includes(q) || u.id.toLowerCase().includes(q);
  });

  // Filtered listings
  const filteredListings = listings.filter((l) => {
    if (selectedGameFilter !== 'ALL' && l.game !== selectedGameFilter) return false;
    if (!listingsSearch.trim()) return true;
    const q = listingsSearch.toLowerCase();
    return (
      l.title.toLowerCase().includes(q) ||
      l.ownerUsername.toLowerCase().includes(q) ||
      l.ownerDiscordTag.toLowerCase().includes(q) ||
      l.offeredItemsText.toLowerCase().includes(q)
    );
  });

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col relative z-20">
      
      {/* Üst Admin Bar */}
      <header className="sticky top-0 z-40 bg-zinc-900/95 border-b border-purple-500/40 backdrop-blur-xl shadow-2xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
          
          {/* Sol: Logo & Admin Rozeti */}
          <div className="flex items-center gap-3">
            <span className="text-2xl sm:text-3xl font-normal tracking-[0.25em] text-transparent bg-clip-text bg-gradient-to-r from-purple-200 to-indigo-300 drop-shadow-[0_0_15px_rgba(168,85,247,0.4)]">
              𝖆𝖑𝖘𝖆𝖙
            </span>
            <div className="h-5 w-px bg-zinc-700 hidden sm:block" />
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-rose-950/80 border border-rose-500/50 text-rose-300 font-mono text-[11px] font-bold shadow-sm">
              <ShieldAlert className="w-3.5 h-3.5 text-rose-400 animate-pulse" />
              <span>ROOT ADMİN KONSOLU</span>
            </div>
          </div>

          {/* Sağ: Aksiyonlar */}
          <div className="flex items-center gap-2.5">
            <button
              onClick={onBackToMarketplace}
              className="px-3.5 py-1.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 hover:text-white text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer border border-zinc-700"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Pazar Vitrini</span>
            </button>

            <button
              onClick={onLogout}
              className="px-3 py-1.5 rounded-xl text-zinc-400 hover:text-rose-400 hover:bg-zinc-800 text-xs font-bold transition-all flex items-center gap-1 cursor-pointer"
              title="Oturumu Kapat"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Çıkış</span>
            </button>
          </div>

        </div>

        {/* Tab Menüsü */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center gap-1 overflow-x-auto no-scrollbar border-t border-zinc-800/80 py-1.5">
          {[
            { id: 'overview', label: 'Genel Bakış & Metrikler', icon: Activity },
            { id: 'listings', label: `İlan Yönetimi (${listings.length})`, icon: Layers },
            { id: 'users', label: `Kullanıcı Yönetimi (${users.length})`, icon: Users },
            { id: 'security', label: 'Güvenlik & Robot Logları', icon: ShieldCheck },
            { id: 'webhook', label: 'Discord & Duyuru', icon: Megaphone },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-3.5 py-1.5 text-xs font-bold rounded-xl flex items-center gap-2 transition-all cursor-pointer shrink-0 ${
                  isActive
                    ? 'bg-purple-600/30 text-purple-200 border border-purple-500/50 shadow-sm'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-800/60'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-purple-400' : 'text-zinc-500'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </header>

      {/* Global Bildirim */}
      {actionMessage && (
        <div
          className={`mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 mt-4 w-full`}
        >
          <div
            className={`p-3 rounded-2xl border text-xs font-medium flex items-center gap-2 shadow-lg animate-in fade-in ${
              actionMessage.type === 'success'
                ? 'bg-emerald-950/80 border-emerald-500/50 text-emerald-200'
                : 'bg-rose-950/80 border-rose-500/50 text-rose-200'
            }`}
          >
            {actionMessage.type === 'success' ? (
              <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
            )}
            <span>{actionMessage.text}</span>
          </div>
        </div>
      )}

      {/* Ana İçerik */}
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 w-full space-y-6">
        
        {/* =========================================================
            TAB 1: GENEL BAKIŞ & METRİKLER (OVERVIEW)
           ========================================================= */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            
            {/* Canlı İstatistik Kartları */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
              
              <div className="bg-zinc-900/80 border border-zinc-800 rounded-2xl p-4 sm:p-5 space-y-2 shadow-lg">
                <div className="flex items-center justify-between text-zinc-400 text-xs">
                  <span className="font-bold">Toplam Kullanıcı</span>
                  <Users className="w-4 h-4 text-purple-400" />
                </div>
                <div className="text-2xl sm:text-3xl font-black text-white font-mono">
                  {stats?.totalUsers ?? '...'}
                </div>
                <div className="text-[10px] text-zinc-500">
                  {stats?.bannedCount ? `${stats.bannedCount} askıya alınmış` : 'Tümü aktif'}
                </div>
              </div>

              <div className="bg-zinc-900/80 border border-zinc-800 rounded-2xl p-4 sm:p-5 space-y-2 shadow-lg">
                <div className="flex items-center justify-between text-zinc-400 text-xs">
                  <span className="font-bold">Aktif İlanlar</span>
                  <Layers className="w-4 h-4 text-indigo-400" />
                </div>
                <div className="text-2xl sm:text-3xl font-black text-white font-mono">
                  {stats?.totalListings ?? '...'}
                </div>
                <div className="text-[10px] text-zinc-500 flex items-center gap-2">
                  <span className="text-rose-400 font-bold">MM2: {stats?.mm2Count ?? 0}</span>
                  <span>•</span>
                  <span className="text-emerald-400 font-bold">Adopt Me: {stats?.adoptMeCount ?? 0}</span>
                </div>
              </div>

              <div className="bg-zinc-900/80 border border-zinc-800 rounded-2xl p-4 sm:p-5 space-y-2 shadow-lg">
                <div className="flex items-center justify-between text-zinc-400 text-xs">
                  <span className="font-bold">Robot Koruması</span>
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                </div>
                <div className="text-2xl sm:text-3xl font-black text-emerald-300 font-mono">
                  {stats?.totalCaptchaPassed ?? 0}
                </div>
                <div className="text-[10px] text-rose-400 font-bold">
                  {stats?.totalCaptchaFailed ?? 0} Engellenen Bot / Hata
                </div>
              </div>

              <div className="bg-zinc-900/80 border border-zinc-800 rounded-2xl p-4 sm:p-5 space-y-2 shadow-lg">
                <div className="flex items-center justify-between text-zinc-400 text-xs">
                  <span className="font-bold">Sunucu Sağlığı</span>
                  <Cpu className="w-4 h-4 text-amber-400" />
                </div>
                <div className="text-2xl sm:text-3xl font-black text-white font-mono">
                  {stats?.memoryUsageMb ?? 0} <span className="text-xs text-zinc-400 font-normal">MB RAM</span>
                </div>
                <div className="text-[10px] text-zinc-500 font-mono">
                  Uptime: {Math.floor((stats?.uptimeSeconds || 0) / 60)} dk
                </div>
              </div>

            </div>

            {/* Global Duyuru Yayıncısı */}
            <div className="bg-zinc-900/80 border border-zinc-800 rounded-3xl p-6 sm:p-7 shadow-xl space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-purple-600/20 border border-purple-500/40 flex items-center justify-center text-purple-400">
                    <Megaphone className="w-4 h-4" />
                  </div>
                  <div>
                    <h2 className="text-base font-black text-white">Canlı Global Sistem Duyurusu</h2>
                    <p className="text-xs text-zinc-400">Sitedeki tüm ziyaretçilerin en üstünde görünecek canlı bildiri metni.</p>
                  </div>
                </div>

                {announcementSuccess && (
                  <span className="text-xs text-emerald-400 font-bold flex items-center gap-1">
                    <Check className="w-3.5 h-3.5" /> Canlıda Yayında
                  </span>
                )}
              </div>

              <form onSubmit={handleUpdateAnnouncement} className="space-y-3">
                <textarea
                  rows={2}
                  value={announcementText}
                  onChange={(e) => setAnnouncementText(e.target.value)}
                  placeholder="Örn: Hafta sonu Adopt Me & MM2 takas etkinliği başladı! Güvenli ticaret yapınız."
                  className="w-full bg-zinc-950 border border-zinc-700 rounded-2xl p-3.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-purple-500"
                />

                <div className="flex items-center justify-end gap-2.5">
                  <button
                    type="submit"
                    disabled={isUpdatingAnnouncement}
                    className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-purple-600/30 transition-all cursor-pointer disabled:opacity-50"
                  >
                    {isUpdatingAnnouncement ? (
                      <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <>
                        <Send className="w-3.5 h-3.5" />
                        <span>Duyuruyu Yayınla / Güncelle</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>

            {/* Son Güvenlik Olayları */}
            <div className="bg-zinc-900/80 border border-zinc-800 rounded-3xl p-6 shadow-xl space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-black text-white flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-purple-400" />
                  <span>Son Güvenlik &amp; Robot Doğrulama Olayları</span>
                </h3>
                <button
                  onClick={fetchOverview}
                  className="text-xs text-zinc-400 hover:text-white flex items-center gap-1 cursor-pointer"
                >
                  <RefreshCw className="w-3 h-3" /> Yenile
                </button>
              </div>

              <div className="space-y-2 max-h-72 overflow-y-auto no-scrollbar font-mono text-[11px]">
                {securityLogs.length === 0 ? (
                  <div className="text-zinc-500 text-center py-6">Kayıtlı güvenlik olayı bulunamadı.</div>
                ) : (
                  securityLogs.slice(0, 10).map((log) => (
                    <div
                      key={log.id}
                      className="p-2.5 bg-zinc-950 border border-zinc-800/80 rounded-xl flex items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-2">
                        <span
                          className={`px-2 py-0.5 rounded text-[9px] font-bold ${
                            log.action === 'CHALLENGE_PASSED'
                              ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/30'
                              : log.action === 'CHALLENGE_FAILED'
                              ? 'bg-rose-950 text-rose-300 border border-rose-500/30'
                              : 'bg-zinc-900 text-zinc-400 border border-zinc-700'
                          }`}
                        >
                          {log.action}
                        </span>
                        <span className="text-zinc-300">{log.details}</span>
                      </div>

                      <div className="text-zinc-500 text-[10px] shrink-0 flex items-center gap-2">
                        <span>IP: {log.ip}</span>
                        <span>•</span>
                        <span>{new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

          </div>
        )}

        {/* =========================================================
            TAB 2: İLAN YÖNETİMİ (LISTINGS MANAGER)
           ========================================================= */}
        {activeTab === 'listings' && (
          <div className="space-y-4">
            
            {/* Arama ve Filtre Çubuğu */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-zinc-900/80 p-4 rounded-2xl border border-zinc-800">
              <div className="flex items-center gap-2 w-full sm:w-auto">
                {(['ALL', 'MM2', 'Adopt Me!'] as const).map((game) => (
                  <button
                    key={game}
                    onClick={() => setSelectedGameFilter(game)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      selectedGameFilter === game
                        ? 'bg-purple-600 text-white shadow-md'
                        : 'bg-zinc-950 text-zinc-400 hover:text-white border border-zinc-800'
                    }`}
                  >
                    {game === 'ALL' ? 'Tümü' : game}
                  </button>
                ))}
              </div>

              <div className="relative w-full sm:w-80">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
                <input
                  type="text"
                  value={listingsSearch}
                  onChange={(e) => setListingsSearch(e.target.value)}
                  placeholder="İlan başlığı, eşya veya kullanıcı ara..."
                  className="w-full bg-zinc-950 border border-zinc-700 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-purple-500"
                />
              </div>
            </div>

            {/* İlanlar Tablosu / Kartları */}
            {isLoadingListings ? (
              <div className="py-20 text-center text-zinc-500 text-xs">İlanlar taranıyor...</div>
            ) : filteredListings.length === 0 ? (
              <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-10 text-center text-zinc-500 text-xs">
                Kriterlere uygun ilan bulunamadı.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredListings.map((listing) => (
                  <div
                    key={listing.id}
                    className="bg-zinc-900/90 border border-zinc-800 hover:border-zinc-700 rounded-2xl p-4 flex flex-col justify-between space-y-3 shadow-lg"
                  >
                    <div className="space-y-2">
                      <div className="flex items-center justify-between gap-2">
                        <span
                          className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-md border ${
                            listing.game === 'MM2'
                              ? 'bg-rose-950/80 text-rose-300 border-rose-500/30'
                              : 'bg-emerald-950/80 text-emerald-300 border-emerald-500/30'
                          }`}
                        >
                          {listing.game}
                        </span>

                        <span className="text-[10px] font-mono text-zinc-500">
                          {new Date(listing.createdAt).toLocaleDateString()}
                        </span>
                      </div>

                      <h4 className="text-sm font-black text-white line-clamp-1">{listing.title}</h4>

                      <div className="text-xs text-zinc-300 space-y-1">
                        <div>
                          <span className="text-emerald-400 font-bold">Verilen: </span>
                          <span className="line-clamp-1 text-zinc-400">{listing.offeredItemsText}</span>
                        </div>
                        <div>
                          <span className="text-purple-400 font-bold">Aranan: </span>
                          <span className="line-clamp-1 text-zinc-400">{listing.lookingForText}</span>
                        </div>
                      </div>

                      <div className="text-[11px] font-mono text-indigo-300 bg-zinc-950 px-2 py-1 rounded-lg border border-zinc-800/80">
                        Sahip: {listing.ownerUsername} (Discord: {listing.ownerDiscordTag})
                      </div>
                    </div>

                    {/* Aksiyon Butonları */}
                    <div className="flex items-center justify-between pt-2 border-t border-zinc-800">
                      {onSelectListingDetail && (
                        <button
                          onClick={() => onSelectListingDetail(listing)}
                          className="text-xs text-zinc-400 hover:text-white flex items-center gap-1 cursor-pointer"
                        >
                          <Eye className="w-3.5 h-3.5" /> İncele
                        </button>
                      )}

                      <button
                        onClick={() => handleDeleteListing(listing.id, listing.title)}
                        className="px-2.5 py-1 rounded-lg bg-rose-950/60 hover:bg-rose-900 border border-rose-500/40 text-rose-300 hover:text-rose-100 text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors"
                        title="İlanı kalıcı olarak sil"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Kaldır</span>
                      </button>
                    </div>

                  </div>
                ))}
              </div>
            )}

          </div>
        )}

        {/* =========================================================
            TAB 3: KULLANICI YÖNETİMİ (USERS MANAGER)
           ========================================================= */}
        {activeTab === 'users' && (
          <div className="space-y-4">
            
            {/* Arama */}
            <div className="flex items-center justify-between bg-zinc-900/80 p-4 rounded-2xl border border-zinc-800">
              <div className="text-xs text-zinc-300 font-bold">
                Toplam Kayıtlı Discord Kullanıcısı: {users.length}
              </div>

              <div className="relative w-72">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
                <input
                  type="text"
                  value={usersSearch}
                  onChange={(e) => setUsersSearch(e.target.value)}
                  placeholder="Discord ismi veya ID ile ara..."
                  className="w-full bg-zinc-950 border border-zinc-700 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-purple-500"
                />
              </div>
            </div>

            {/* Kullanıcı Listesi Tablosu */}
            <div className="bg-zinc-900/90 border border-zinc-800 rounded-3xl overflow-hidden shadow-xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-zinc-950 border-b border-zinc-800 text-zinc-400 font-mono uppercase text-[10px]">
                    <tr>
                      <th className="py-3.5 px-4">Discord İsmi</th>
                      <th className="py-3.5 px-4">Rol / Yetki</th>
                      <th className="py-3.5 px-4">İlan Sayısı</th>
                      <th className="py-3.5 px-4">Durum</th>
                      <th className="py-3.5 px-4">Kayıt Tarihi</th>
                      <th className="py-3.5 px-4 text-right">Yönetim Aksiyonu</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-800/80">
                    {filteredUsers.map((user) => {
                      const isMainAdmin = user.username === '1231321323';
                      return (
                        <tr key={user.id} className="hover:bg-zinc-800/40 transition-colors">
                          <td className="py-3 px-4 font-bold text-white flex items-center gap-2">
                            <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center text-white text-xs font-black shadow-inner">
                              {user.username.charAt(0).toUpperCase()}
                            </div>
                            <div>
                              <div>{user.username}</div>
                              <div className="text-[10px] text-zinc-500 font-mono">{user.id}</div>
                            </div>
                          </td>

                          <td className="py-3 px-4">
                            {isMainAdmin ? (
                              <span className="px-2 py-0.5 rounded-md bg-purple-950 text-purple-300 border border-purple-500/40 font-mono text-[10px] font-bold">
                                ROOT ADMİN
                              </span>
                            ) : (
                              <span className="text-zinc-400 font-mono text-[11px]">STANDART</span>
                            )}
                          </td>

                          <td className="py-3 px-4 font-mono font-bold text-indigo-300">
                            {user.listingsCount} ilan
                          </td>

                          <td className="py-3 px-4">
                            {user.isBanned ? (
                              <span className="px-2 py-0.5 rounded-md bg-rose-950 text-rose-300 border border-rose-500/40 font-mono text-[10px] font-bold">
                                YASAKLI
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 rounded-md bg-emerald-950 text-emerald-300 border border-emerald-500/40 font-mono text-[10px] font-bold">
                                AKTİF
                              </span>
                            )}
                          </td>

                          <td className="py-3 px-4 text-zinc-400 font-mono text-[11px]">
                            {new Date(user.createdAt).toLocaleDateString()}
                          </td>

                          <td className="py-3 px-4 text-right">
                            {isMainAdmin ? (
                              <span className="text-zinc-500 text-[10px] italic">Korumalı Hesap</span>
                            ) : (
                              <div className="flex items-center justify-end gap-2">
                                <button
                                  onClick={() => handleToggleBan(user)}
                                  className={`px-2.5 py-1 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                                    user.isBanned
                                      ? 'bg-emerald-950 text-emerald-300 border-emerald-500/40 hover:bg-emerald-900'
                                      : 'bg-amber-950/80 text-amber-300 border-amber-500/40 hover:bg-amber-900'
                                  }`}
                                  title={user.isBanned ? 'Yasağı Kaldır' : 'Kullanıcıyı Yasakla'}
                                >
                                  {user.isBanned ? 'Yasağı Aç' : 'Yasakla'}
                                </button>

                                <button
                                  onClick={() => handleDeleteUser(user)}
                                  className="p-1 rounded-lg bg-zinc-800 hover:bg-rose-950 text-zinc-400 hover:text-rose-300 border border-transparent hover:border-rose-500/40 transition-colors cursor-pointer"
                                  title="Kullanıcıyı ve ilanlarını sil"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        )}

        {/* =========================================================
            TAB 4: GÜVENLİK & ROBOT LOGLARI (SECURITY LOGS)
           ========================================================= */}
        {activeTab === 'security' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between bg-zinc-900/80 p-4 rounded-2xl border border-zinc-800">
              <div>
                <h3 className="text-sm font-black text-white">Robot Doğrulaması &amp; Güvenlik Günlüğü</h3>
                <p className="text-xs text-zinc-400">Girişteki gerçek robot doğrulamasına ait tüm başarılı ve engellenen denemeler.</p>
              </div>

              <button
                onClick={fetchOverview}
                className="px-3 py-1.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-xs text-white font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Yenile</span>
              </button>
            </div>

            <div className="bg-zinc-900/90 border border-zinc-800 rounded-3xl p-5 shadow-xl space-y-2 font-mono text-xs max-h-[600px] overflow-y-auto">
              {securityLogs.length === 0 ? (
                <div className="text-zinc-500 text-center py-12">Henüz güvenlik kaydı yok.</div>
              ) : (
                securityLogs.map((log) => (
                  <div
                    key={log.id}
                    className="p-3 bg-zinc-950 border border-zinc-800/90 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                  >
                    <div className="flex items-center gap-2">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          log.action === 'CHALLENGE_PASSED'
                            ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/40'
                            : log.action === 'CHALLENGE_FAILED'
                            ? 'bg-rose-950 text-rose-300 border border-rose-500/40'
                            : 'bg-zinc-800 text-zinc-300'
                        }`}
                      >
                        {log.action}
                      </span>
                      <span className="text-zinc-200">{log.details}</span>
                    </div>

                    <div className="text-[11px] text-zinc-500 flex items-center gap-3">
                      <span>IP: {log.ip}</span>
                      <span>{new Date(log.timestamp).toLocaleString()}</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* =========================================================
            TAB 5: DISCORD & SİSTEM ARAÇLARI (WEBHOOK & SYSTEM)
           ========================================================= */}
        {activeTab === 'webhook' && (
          <div className="space-y-6">
            
            {/* Discord Webhook Test Formu */}
            <div className="bg-zinc-900/90 border border-zinc-800 rounded-3xl p-6 sm:p-7 shadow-xl space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-indigo-600/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400">
                  <Megaphone className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-white">Discord Webhook Entegrasyon Testi</h3>
                  <p className="text-xs text-zinc-400">
                    Discord kanalına anlık test bildirimi göndererek webhook bağlantısını test edin.
                  </p>
                </div>
              </div>

              {webhookResult && (
                <div
                  className={`p-3 rounded-xl border text-xs font-medium flex items-center gap-2 ${
                    webhookResult.success
                      ? 'bg-emerald-950/80 border-emerald-500/40 text-emerald-200'
                      : 'bg-rose-950/80 border-rose-500/40 text-rose-200'
                  }`}
                >
                  {webhookResult.success ? (
                    <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                  ) : (
                    <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                  )}
                  <span>{webhookResult.text}</span>
                </div>
              )}

              <form onSubmit={handleSendTestWebhook} className="space-y-3">
                <input
                  type="text"
                  value={testWebhookMsg}
                  onChange={(e) => setTestWebhookMsg(e.target.value)}
                  placeholder="Özel test mesajı (İsteğe bağlı)..."
                  className="w-full bg-zinc-950 border border-zinc-700 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-purple-500"
                />

                <button
                  type="submit"
                  disabled={isSendingWebhook}
                  className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-2 transition-all cursor-pointer disabled:opacity-50"
                >
                  {isSendingWebhook ? (
                    <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>
                      <Send className="w-3.5 h-3.5" />
                      <span>Test Bildirimi Gönder</span>
                    </>
                  )}
                </button>
              </form>
            </div>

            {/* Sistem Bilgi Kartı */}
            <div className="bg-zinc-900/70 border border-zinc-800 rounded-3xl p-6 shadow-xl space-y-3 font-mono text-xs">
              <h4 className="text-xs uppercase font-bold text-zinc-400 tracking-wider">
                Sunucu Altyapı Bilgileri
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-zinc-300">
                <div className="p-3 bg-zinc-950 rounded-xl border border-zinc-800/80">
                  <span className="text-zinc-500">Node Environment: </span>
                  <span className="font-bold text-purple-400">Full-Stack Express + Vite</span>
                </div>
                <div className="p-3 bg-zinc-950 rounded-xl border border-zinc-800/80">
                  <span className="text-zinc-500">Admin Yetkisi: </span>
                  <span className="font-bold text-emerald-400">1231321323 (Root Admin)</span>
                </div>
              </div>
            </div>

          </div>
        )}

      </main>
    </div>
  );
};
