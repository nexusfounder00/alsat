import React, { useState } from 'react';
import {
  Copy,
  Check,
  Clock,
  ShieldCheck,
  Tag,
  ExternalLink,
  Eye,
  Sparkles,
} from 'lucide-react';
import { Listing } from '../types/listing';

interface ListingCardProps {
  listing: Listing;
  onSelect?: (listing: Listing) => void;
}

export const ListingCard: React.FC<ListingCardProps> = ({ listing, onSelect }) => {
  const [copiedDiscord, setCopiedDiscord] = useState(false);

  const handleCopyDiscord = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(listing.ownerDiscordTag);
    setCopiedDiscord(true);
    setTimeout(() => setCopiedDiscord(false), 2500);
  };

  const isMM2 = listing.game === 'MM2';

  return (
    <div
      onClick={() => onSelect?.(listing)}
      className="bg-zinc-900/90 border border-zinc-800 hover:border-purple-500/60 rounded-2xl p-4 sm:p-5 flex flex-col justify-between shadow-xl transition-all duration-200 relative overflow-hidden backdrop-blur-sm group cursor-pointer hover:shadow-2xl hover:shadow-purple-950/20 hover:-translate-y-0.5"
    >
      {/* Üst Bilgi: Oyun Rozeti, Tarih & Discord Kopyalama */}
      <div>
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="flex items-center gap-2">
            <span
              className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-lg border font-['Rajdhani'] ${
                isMM2
                  ? 'bg-rose-950/70 text-rose-300 border-rose-500/40'
                  : 'bg-emerald-950/70 text-emerald-300 border-emerald-500/40'
              }`}
            >
              <span className="font-['Orbitron'] font-black mr-1 text-[9px] text-white">
                {isMM2 ? 'MM2' : 'ADOPT ME'}
              </span>
              <span>{isMM2 ? 'Pazarı' : 'Pazarı'}</span>
            </span>
            <span className="text-[10px] text-zinc-500 flex items-center gap-1 font-mono">
              <Clock className="w-3 h-3" />
              {new Date(listing.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </span>
          </div>

          {/* Hızlı Discord Kopyalama Butonu */}
          <button
            onClick={handleCopyDiscord}
            className="shrink-0 px-2.5 py-1 rounded-xl bg-indigo-950/70 hover:bg-indigo-900 border border-indigo-500/40 text-indigo-300 hover:text-white text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer shadow-sm z-10"
            title="Discord ismini panoya kopyala"
          >
            {copiedDiscord ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-300 text-[11px] font-mono">Kopyalandı!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-indigo-400" />
                <span className="font-mono text-[11px]">{listing.ownerDiscordTag}</span>
              </>
            )}
          </button>
        </div>

        {/* İlan Başlığı & Detay Butonu */}
        <div className="flex items-start justify-between gap-2 mb-2">
          <h3 className="text-base font-black text-white tracking-tight leading-snug group-hover:text-purple-300 transition-colors">
            {listing.title}
          </h3>
          <span className="shrink-0 p-1 rounded-lg bg-zinc-800/80 group-hover:bg-purple-600 group-hover:text-white text-zinc-400 transition-colors text-xs flex items-center gap-1">
            <Eye className="w-3.5 h-3.5" />
          </span>
        </div>

        {/* İlan Açıklaması */}
        <p className="text-xs text-zinc-400 leading-relaxed mb-4 line-clamp-2">
          {listing.description}
        </p>

        {/* İlana Yüklenen Görsel */}
        {listing.imageUrl && (
          <div className="mb-4 rounded-xl overflow-hidden border border-zinc-800 bg-zinc-950 max-h-52 flex items-center justify-center relative group-hover:border-zinc-700 transition-colors">
            <img
              src={listing.imageUrl}
              alt={listing.title}
              className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-102"
              onError={(e: any) => {
                e.currentTarget.style.display = 'none';
              }}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end justify-center pb-2">
              <span className="text-[11px] text-zinc-200 font-bold bg-black/80 px-2.5 py-1 rounded-lg border border-zinc-700">
                Detayları İncele
              </span>
            </div>
          </div>
        )}

        {/* Verdiğim / Sunduğum Şey */}
        <div className="bg-zinc-950/80 rounded-xl p-3 border border-zinc-800 mb-2.5 space-y-1">
          <div className="text-[10px] uppercase font-bold text-emerald-400 tracking-wider flex items-center gap-1">
            <Tag className="w-3 h-3" />
            <span>Verdiğim / Sunduğum:</span>
          </div>
          <div className="text-xs font-bold text-white whitespace-pre-line line-clamp-2">
            {listing.offeredItemsText}
          </div>
        </div>

        {/* Aradığım / İstediğim Şey */}
        <div className="bg-purple-950/20 rounded-xl p-3 border border-purple-500/20 mb-4 space-y-1">
          <div className="text-[10px] uppercase font-bold text-purple-300 tracking-wider flex items-center gap-1">
            <Tag className="w-3 h-3" />
            <span>Aradığım / İstediğim:</span>
          </div>
          <div className="text-xs font-bold text-zinc-200 whitespace-pre-line line-clamp-2">
            {listing.lookingForText}
          </div>
        </div>
      </div>

      {/* Alt Bölüm: İlan Sahibi Bilgisi & Discord İletişim Butonu */}
      <div className="border-t border-zinc-800/80 pt-3 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center text-white text-xs font-black shrink-0">
            {listing.ownerUsername.charAt(0).toUpperCase()}
          </div>
          <div className="truncate">
            <div className="text-xs font-bold text-white flex items-center gap-1 truncate">
              <span>{listing.ownerUsername}</span>
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            </div>
            <div className="text-[10px] text-indigo-400 font-mono truncate">
              {listing.ownerDiscordTag}
            </div>
          </div>
        </div>

        {/* Discord İletişim Butonu */}
        <button
          onClick={handleCopyDiscord}
          className="shrink-0 px-3 py-2 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-indigo-600/30 transition-all cursor-pointer z-10"
        >
          {copiedDiscord ? (
            <>
              <Check className="w-3.5 h-3.5 text-emerald-300" />
              <span>Discord Kopyalandı</span>
            </>
          ) : (
            <>
              <Copy className="w-3.5 h-3.5" />
              <span>İletişime Geç</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
