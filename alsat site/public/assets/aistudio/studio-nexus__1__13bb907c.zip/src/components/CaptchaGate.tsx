import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  ShieldCheck,
  ShieldAlert,
  RotateCw,
  ArrowRight,
  Bot,
  Lock,
  Sparkles,
  CheckCircle2,
  Cpu,
} from 'lucide-react';

interface CaptchaChallengeResponse {
  challengeId: string;
  type: 'code' | 'math';
  code: string;
  mathPrompt?: string;
  seed: number;
  expiresInSeconds: number;
}

interface CaptchaGateProps {
  onVerified: () => void;
}

export const CaptchaGate: React.FC<CaptchaGateProps> = ({ onVerified }) => {
  const [challenge, setChallenge] = useState<CaptchaChallengeResponse | null>(null);
  const [userInput, setUserInput] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [isVerifying, setIsVerifying] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // İnsan Telemetrisi: Botları ayırt etmek için etkileşim takibi
  const startTimeRef = useRef<number>(Date.now());
  const mouseMovesRef = useRef<number>(0);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const fetchChallenge = useCallback(async () => {
    setIsLoading(true);
    setErrorMessage(null);
    setUserInput('');
    startTimeRef.current = Date.now();
    mouseMovesRef.current = 0;

    try {
      const res = await fetch('/api/security/captcha/challenge');
      if (!res.ok) throw new Error('Güvenlik servisine ulaşılamadı.');
      const data = await res.json();
      setChallenge(data);
    } catch (err: any) {
      setErrorMessage(err.message || 'Güvenlik kodu yüklenemedi. Lütfen tekrar deneyin.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchChallenge();
  }, [fetchChallenge]);

  // Fare hareketlerini say (otonom script telemetrisi)
  const handleMouseMove = () => {
    mouseMovesRef.current += 1;
  };

  // Canvas üzerine gerçek bozulmalı (distorted) güvenlik grafiği çizme
  useEffect(() => {
    if (!challenge || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    // 1. Arka planı temizle ve siber ızgara arka planı çiz
    ctx.fillStyle = '#09090b';
    ctx.fillRect(0, 0, width, height);

    // 2. Rastgele gürültü pikselleri (Salt & Pepper Noise)
    for (let i = 0; i < 240; i++) {
      ctx.fillStyle = i % 2 === 0 ? 'rgba(168, 85, 247, 0.25)' : 'rgba(99, 102, 241, 0.25)';
      ctx.fillRect(Math.random() * width, Math.random() * height, 2, 2);
    }

    // 3. Karışıklık çizgileri (Interference Wavy Lines)
    for (let i = 0; i < 4; i++) {
      ctx.beginPath();
      ctx.moveTo(Math.random() * 20, Math.random() * height);
      ctx.bezierCurveTo(
        Math.random() * width * 0.5,
        Math.random() * height,
        Math.random() * width * 0.8,
        Math.random() * height,
        width - Math.random() * 20,
        Math.random() * height
      );
      ctx.strokeStyle = i % 2 === 0 ? 'rgba(236, 72, 153, 0.4)' : 'rgba(59, 130, 246, 0.4)';
      ctx.lineWidth = 1.5;
      ctx.stroke();
    }

    // 4. Metni / Matematik İfadesini Karakter Karakter Çiz (Açı, Bozulma ve Gölge ile)
    const textToDraw = challenge.code;
    const charCount = textToDraw.length;
    const charSpacing = width / (charCount + 1);

    ctx.textBaseline = 'middle';
    ctx.font = 'bold 26px Orbitron, monospace';

    for (let i = 0; i < charCount; i++) {
      const char = textToDraw[i];
      ctx.save();

      const x = charSpacing * (i + 1) + (Math.random() * 4 - 2);
      const y = height / 2 + (Math.random() * 6 - 3);
      const angle = (Math.random() * 24 - 12) * (Math.PI / 180);

      ctx.translate(x, y);
      ctx.rotate(angle);

      // Neon gölge efekti
      ctx.shadowColor = i % 2 === 0 ? '#a855f7' : '#6366f1';
      ctx.shadowBlur = 8;
      ctx.fillStyle = '#ffffff';

      ctx.fillText(char, -8, 0);
      ctx.restore();
    }
  }, [challenge]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!challenge || !userInput.trim() || isVerifying || isSuccess) return;

    setIsVerifying(true);
    setErrorMessage(null);

    const durationMs = Date.now() - startTimeRef.current;
    const humanMetrics = {
      durationMs,
      mouseMovements: mouseMovesRef.current,
      hasInteracted: true,
    };

    try {
      const res = await fetch('/api/security/captcha/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          challengeId: challenge.challengeId,
          answer: userInput.trim(),
          humanMetrics,
        }),
      });

      const data = await res.json();

      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Doğrulama başarısız oldu. Lütfen tekrar deneyin.');
      }

      // Başarılı: Token'ı sakla
      if (data.token) {
        sessionStorage.setItem('alsat_captcha_verified', data.token);
      }

      setIsSuccess(true);
      // Animasyonlu akıcı yönlendirme (1.1 saniye sonra)
      setTimeout(() => {
        onVerified();
      }, 1100);
    } catch (err: any) {
      setErrorMessage(err.message || 'Güvenlik kodu hatalı.');
      // Yeni kod üret
      setTimeout(() => {
        fetchChallenge();
      }, 700);
    } finally {
      setIsVerifying(false);
    }
  };

  return (
    <div
      onMouseMove={handleMouseMove}
      className="min-h-screen flex flex-col items-center justify-center p-4 sm:p-6 relative overflow-hidden select-none"
    >
      {/* Kart Konteyneri */}
      <div className="relative z-10 w-full max-w-md bg-zinc-900/90 border border-zinc-700/80 rounded-3xl p-6 sm:p-8 shadow-[0_20px_60px_rgba(0,0,0,0.9)] backdrop-blur-2xl text-center space-y-6">
        
        {/* Dekoratif Işık Efekti */}
        <div className="absolute -top-20 -right-20 w-44 h-44 bg-purple-600/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-20 -left-20 w-44 h-44 bg-indigo-600/20 rounded-full blur-3xl pointer-events-none" />

        {/* Üst Logo ve Başlık */}
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-950/80 border border-purple-500/40 text-purple-300 text-[11px] font-mono font-bold tracking-wider">
            <Cpu className="w-3.5 h-3.5 text-purple-400 animate-pulse" />
            <span>SİBER GÜVENLİK KALKANI</span>
          </div>

          <div>
            <span className="text-4xl sm:text-5xl font-normal tracking-[0.25em] text-transparent bg-clip-text bg-gradient-to-r from-purple-100 via-zinc-100 to-indigo-200 drop-shadow-[0_0_25px_rgba(168,85,247,0.5)]">
              𝖆𝖑𝖘𝖆𝖙
            </span>
          </div>

          <h1 className="text-lg font-black text-white tracking-tight">
            Robot Doğrulaması (İnsan Kontrolü)
          </h1>
          <p className="text-xs text-zinc-400 max-w-xs mx-auto leading-relaxed">
            Pazar ağına erişmeden önce otomatik bot saldırılarını engellemek için lütfen güvenliği doğrulayın.
          </p>
        </div>

        {/* Hata Bildirimi */}
        {errorMessage && (
          <div className="p-3 bg-red-950/80 border border-red-500/50 rounded-xl text-red-200 text-xs flex items-center gap-2 animate-in fade-in duration-150">
            <ShieldAlert className="w-4 h-4 shrink-0 text-red-400" />
            <span className="text-left flex-1">{errorMessage}</span>
          </div>
        )}

        {/* Başarılı Onay Bildirimi */}
        {isSuccess ? (
          <div className="py-8 space-y-3 animate-in zoom-in-95 duration-200">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 border-2 border-emerald-400 flex items-center justify-center mx-auto text-emerald-400 shadow-[0_0_30px_rgba(16,185,129,0.5)]">
              <CheckCircle2 className="w-9 h-9 animate-bounce" />
            </div>
            <div className="text-base font-black text-white">İnsan Olduğunuz Doğrulandı!</div>
            <p className="text-xs text-emerald-300 font-mono">
              Giriş terminaline yönlendiriliyorsunuz...
            </p>
          </div>
        ) : (
          /* Form & Canvas Doğrulama Alanı */
          <form onSubmit={handleSubmit} className="space-y-4">
            
            {/* Canvas Kutusu */}
            <div className="bg-zinc-950 p-3 rounded-2xl border border-zinc-800 shadow-inner relative overflow-hidden group">
              <div className="flex items-center justify-between pb-2 mb-2 border-b border-zinc-800/80 text-[10px] font-mono text-zinc-400">
                <span className="flex items-center gap-1">
                  <Bot className="w-3.5 h-3.5 text-purple-400" />
                  {challenge?.type === 'math' ? 'Matematik Güvenlik Sorusu' : 'Bozulmalı Güvenlik Kodu'}
                </span>

                <button
                  type="button"
                  onClick={fetchChallenge}
                  disabled={isLoading || isVerifying}
                  className="hover:text-purple-300 transition-colors flex items-center gap-1 cursor-pointer disabled:opacity-50"
                  title="Yeni kod üret"
                >
                  <RotateCw className={`w-3 h-3 ${isLoading ? 'animate-spin' : ''}`} />
                  <span>Yenile</span>
                </button>
              </div>

              {/* Gerçek Bozulmalı Doğrulama Grafiği (Canvas) */}
              <div className="flex justify-center items-center py-1">
                {isLoading ? (
                  <div className="h-16 flex items-center justify-center gap-2 text-xs text-zinc-500 font-mono">
                    <div className="w-4 h-4 border-2 border-purple-500 border-t-transparent rounded-full animate-spin" />
                    <span>Güvenlik kodu oluşturuluyor...</span>
                  </div>
                ) : (
                  <canvas
                    ref={canvasRef}
                    width={280}
                    height={64}
                    className="rounded-xl border border-zinc-800 shadow-lg select-none pointer-events-none"
                  />
                )}
              </div>

              <div className="text-[10px] text-zinc-500 pt-1.5 flex items-center justify-center gap-1">
                <Lock className="w-3 h-3 text-zinc-600" />
                <span>
                  {challenge?.type === 'math'
                    ? 'İşlemin sonucunu aşağıdaki kutuya yazın'
                    : 'Yukarıda gördüğünüz karakterleri kutuya yazın'}
                </span>
              </div>
            </div>

            {/* Yanıt Giriş Kutusu */}
            <div>
              <input
                type="text"
                required
                autoFocus
                maxLength={8}
                value={userInput}
                onChange={(e) => setUserInput(e.target.value.toUpperCase())}
                placeholder={challenge?.type === 'math' ? 'İşlemin Sonucu (Örn: 42)' : 'Kodu Girin'}
                className="w-full text-center tracking-[0.3em] font-['Orbitron'] font-black text-lg bg-zinc-950 border border-zinc-700 rounded-xl py-3 text-white placeholder-zinc-600 focus:outline-none focus:border-purple-500 transition-all shadow-inner"
              />
            </div>

            {/* Doğrula ve Girişe Geç Butonu */}
            <button
              type="submit"
              disabled={isLoading || isVerifying || !userInput.trim()}
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-600 hover:from-purple-500 hover:to-indigo-500 text-white font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-purple-600/30 transition-all cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isVerifying ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Siber Doğrulama Yapılıyor...</span>
                </>
              ) : (
                <>
                  <ShieldCheck className="w-4 h-4 text-purple-200" />
                  <span>Doğrula ve Girişe Geç</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>
        )}

        {/* Güvenlik Damgası */}
        <div className="pt-2 text-[10px] font-mono text-zinc-500 flex items-center justify-center gap-1.5">
          <Sparkles className="w-3 h-3 text-purple-400" />
          <span>Alsat CyberShield v3.8 • 256-bit Doğrulama</span>
        </div>

      </div>
    </div>
  );
};
