import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  CheckCircle2,
  Lock,
  ArrowRight,
  Terminal,
  Activity,
} from 'lucide-react';
import { User } from '../types/auth';

interface LogoutModalProps {
  isOpen: boolean;
  currentUser: User | null;
  onConfirmLogout: () => void;
  onCancel: () => void;
}

export const LogoutModal: React.FC<LogoutModalProps> = ({
  isOpen,
  currentUser,
  onConfirmLogout,
  onCancel,
}) => {
  const [progress, setProgress] = useState(0);
  const [stage, setStage] = useState(0);
  const [isFinishing, setIsFinishing] = useState(false);

  useEffect(() => {
    if (!isOpen) {
      setProgress(0);
      setStage(0);
      setIsFinishing(false);
      return;
    }

    // Aşamalı animasyon akışı (Cool & Futuristic Game HUD Experience)
    const timer1 = setTimeout(() => {
      setProgress(35);
      setStage(1);
    }, 200);

    const timer2 = setTimeout(() => {
      setProgress(75);
      setStage(2);
    }, 550);

    const timer3 = setTimeout(() => {
      setProgress(100);
      setStage(3);
      setIsFinishing(true);
    }, 950);

    const timer4 = setTimeout(() => {
      onConfirmLogout();
    }, 1300);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
      clearTimeout(timer4);
    };
  }, [isOpen, onConfirmLogout]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="relative bg-zinc-950 border border-zinc-800 rounded-2xl w-full max-w-md shadow-2xl overflow-hidden p-6 sm:p-7 space-y-5 animate-in zoom-in-95 duration-200 text-left"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Arka plan süzülen neon ışıltısı */}
        <div className="absolute -top-16 -right-16 w-44 h-44 bg-purple-600/20 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute -bottom-16 -left-16 w-44 h-44 bg-emerald-600/15 rounded-full blur-2xl pointer-events-none" />

        {/* 1. Üst Başlık & Cyber Terminal Rozeti */}
        <div className="flex items-center justify-between border-b border-zinc-800/80 pb-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400">
              <Terminal className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-mono font-bold text-zinc-300 tracking-wider">
                GÜVENLİ ÇIKIŞ PROTOKOLÜ
              </span>
              <p className="text-[10px] text-zinc-500 font-mono">
                SESSION_TERMINATION // STATUS_SYNC
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-zinc-900 border border-zinc-800 text-[10px] font-mono text-purple-300">
            <Activity className="w-3 h-3 text-purple-400 animate-pulse" />
            <span>%{progress}</span>
          </div>
        </div>

        {/* 2. Kullanıcı Kartı Özeti */}
        {currentUser && (
          <div className="bg-zinc-900/80 border border-zinc-800 rounded-xl p-3 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-lg bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center text-white text-xs font-black shadow-sm">
                {currentUser.username.charAt(0).toUpperCase()}
              </div>
              <div>
                <div className="text-xs font-bold text-white leading-tight">
                  {currentUser.username}
                </div>
                <div className="text-[10px] text-indigo-400 font-mono">
                  {currentUser.discordTag}
                </div>
              </div>
            </div>

            <div className="text-[10px] text-zinc-500 font-mono text-right">
              <span className="text-emerald-400">Aktif İlanlar Korunuyor</span>
            </div>
          </div>
        )}

        {/* 3. Aşamalı Terminal Doğrulama Adımları (Geliştirilebilir Durumlar) */}
        <div className="space-y-2 font-mono text-[11px]">
          <div className="flex items-center gap-2 transition-colors">
            {stage >= 1 ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : (
              <div className="w-4 h-4 rounded-full border border-zinc-700 flex items-center justify-center shrink-0">
                <div className="w-1.5 h-1.5 rounded-full bg-purple-400 animate-ping" />
              </div>
            )}
            <span className={stage >= 1 ? 'text-zinc-200' : 'text-zinc-500'}>
              Oturum anahtarları şifreleniyor...
            </span>
          </div>

          <div className="flex items-center gap-2 transition-colors">
            {stage >= 2 ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : stage === 1 ? (
              <div className="w-4 h-4 rounded-full border border-zinc-700 flex items-center justify-center shrink-0">
                <div className="w-1.5 h-1.5 rounded-full bg-purple-400 animate-ping" />
              </div>
            ) : (
              <div className="w-4 h-4 rounded-full border border-zinc-800 shrink-0" />
            )}
            <span className={stage >= 2 ? 'text-zinc-200' : 'text-zinc-500'}>
              İlan durumları ve Discord etiketi kaydedildi
            </span>
          </div>

          <div className="flex items-center gap-2 transition-colors">
            {stage >= 3 ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : stage === 2 ? (
              <div className="w-4 h-4 rounded-full border border-zinc-700 flex items-center justify-center shrink-0">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
              </div>
            ) : (
              <div className="w-4 h-4 rounded-full border border-zinc-800 shrink-0" />
            )}
            <span className={stage >= 3 ? 'text-emerald-300 font-bold' : 'text-zinc-500'}>
              Bağlantı güvenli şekilde sonlandırıldı
            </span>
          </div>
        </div>

        {/* 4. Dinamik İlerleme Çubuğu */}
        <div className="space-y-1">
          <div className="w-full bg-zinc-900 border border-zinc-800 rounded-full h-1.5 overflow-hidden">
            <div
              className="bg-gradient-to-r from-purple-500 via-indigo-500 to-emerald-400 h-full transition-all duration-300 ease-out"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        {/* 5. Alt Bilgi & İptal / Hızlı Tamamla */}
        <div className="pt-2 flex items-center justify-between text-xs border-t border-zinc-800/80">
          <button
            type="button"
            onClick={onCancel}
            disabled={isFinishing}
            className="text-zinc-400 hover:text-white transition-colors text-[11px] font-medium disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer"
          >
            Vazgeç
          </button>

          <button
            type="button"
            onClick={onConfirmLogout}
            className="px-3 py-1.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 hover:text-white font-mono text-[11px] flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <span>Hızlı Kapat</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>
      </div>
    </div>
  );
};
