import React from 'react';
import { Sparkles, ArrowRight, CheckCircle2, Flame, Layers, ShieldCheck } from 'lucide-react';
import { Listing } from '../types/listing';

interface CategoryShowcaseProps {
  selectedGame: 'Adopt Me!' | 'MM2' | 'ALL';
  onSelectGame: (game: 'Adopt Me!' | 'MM2' | 'ALL') => void;
  listings: Listing[];
}

export const CategoryShowcase: React.FC<CategoryShowcaseProps> = ({
  selectedGame,
  onSelectGame,
  listings,
}) => {
  const mm2ListingsCount = listings.filter((l) => l.game === 'MM2').length;
  const adoptMeListingsCount = listings.filter((l) => l.game === 'Adopt Me!').length;

  const mm2FeaturedItems = [
    { name: 'Harvester', img: '/assets/mm2/harvester.png', rarity: 'Ancient' },
    { name: 'Corrupt', img: '/assets/mm2/corrupt.png', rarity: 'Unique' },
    { name: 'Batwing', img: '/assets/mm2/batwing.png', rarity: 'Ancient' },
    { name: 'Icepiercer', img: '/assets/mm2/icepiercer.png', rarity: 'Ancient' },
    { name: 'Candy', img: '/assets/mm2/candy.png', rarity: 'Godly' },
    { name: 'Chroma Fang', img: '/assets/mm2/chroma-fang.png', rarity: 'Chroma' },
  ];

  const adoptMeFeaturedItems = [
    { name: 'Shadow Dragon', img: '/assets/adoptme/shadow-dragon.png', rarity: 'Legendary' },
    { name: 'Bat Dragon', img: '/assets/adoptme/bat-dragon.png', rarity: 'Legendary' },
    { name: 'Frost Dragon', img: '/assets/adoptme/frost-dragon.png', rarity: 'Legendary' },
    { name: 'Giraffe', img: '/assets/adoptme/giraffe.png', rarity: 'Legendary' },
    { name: 'Owl', img: '/assets/adoptme/owl.png', rarity: 'Legendary' },
    { name: 'Fly Potion', img: '/assets/adoptme/fly-potion.png', rarity: 'Potion' },
  ];

  return (
    <div className="space-y-4">
      {/* Kategori Başlığı ve "Tümünü Gör" Kontrolü */}
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-2.5">
          <div className="w-2.5 h-2.5 rounded-full bg-gradient-to-r from-rose-500 to-emerald-400 animate-pulse shadow-[0_0_12px_rgba(244,63,94,0.7)]" />
          <h2 className="text-xs sm:text-sm font-black uppercase tracking-wider text-zinc-200 flex items-center gap-2">
            <span>Öne Çıkan Oyun Kategorileri</span>
            <span className="text-[10px] text-zinc-500 font-mono font-normal">| Roblox Pazarı</span>
          </h2>
        </div>

        {selectedGame !== 'ALL' && (
          <button
            onClick={() => onSelectGame('ALL')}
            className="text-xs text-purple-400 hover:text-purple-300 font-bold flex items-center gap-1.5 transition-all bg-purple-950/40 hover:bg-purple-900/60 border border-purple-500/30 px-3 py-1.5 rounded-xl cursor-pointer"
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Filtreyi Sıfırla (Tümü: {listings.length})</span>
          </button>
        )}
      </div>

      {/* 2 Ana Kategori Kartı (MM2 ve Adopt Me!) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
        
        {/* =========================================
            1. MURDER MYSTERY 2 (MM2) KATEGORİ KARTI
           ========================================= */}
        <div
          onClick={() => onSelectGame(selectedGame === 'MM2' ? 'ALL' : 'MM2')}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              onSelectGame(selectedGame === 'MM2' ? 'ALL' : 'MM2');
            }
          }}
          className={`relative group rounded-3xl overflow-hidden p-5 sm:p-6 border transition-all duration-300 cursor-pointer text-left select-none ${
            selectedGame === 'MM2'
              ? 'bg-gradient-to-br from-rose-950/90 via-zinc-950 to-zinc-950 border-rose-500 shadow-[0_0_35px_rgba(244,63,94,0.35)] ring-2 ring-rose-500/80 scale-[1.01]'
              : 'bg-zinc-950/80 hover:bg-zinc-900/90 border-zinc-800/90 hover:border-rose-500/60 hover:shadow-xl hover:shadow-rose-950/30'
          }`}
        >
          {/* Arka plan süzülen neon rengi & parıltı */}
          <div className="absolute -top-16 -right-16 w-56 h-56 bg-rose-600/20 rounded-full blur-3xl group-hover:bg-rose-600/30 transition-all pointer-events-none" />
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-rose-600 via-red-500 to-rose-700 opacity-60 group-hover:opacity-100 transition-opacity" />

          <div className="relative z-10 flex flex-col justify-between h-full space-y-4">
            
            {/* Üst Kısım: Rozet ve İlan Sayacı */}
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center text-xl shadow-inner group-hover:scale-105 transition-transform">
                  🔪
                </div>
                <div>
                  <div className="text-[11px] font-mono font-bold uppercase tracking-wider text-rose-400 flex items-center gap-1.5">
                    <span>Murder Mystery 2</span>
                    <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
                  </div>
                  <div className="text-[10px] text-zinc-400 font-mono">Bıçak & Silah Pazarı</div>
                </div>
              </div>

              <div className="flex items-center gap-1.5">
                <span className="px-3 py-1 rounded-xl bg-rose-950/90 border border-rose-500/40 text-rose-300 text-xs font-mono font-bold shadow-sm">
                  {mm2ListingsCount} İlan Aktif
                </span>
                {selectedGame === 'MM2' && (
                  <span className="flex items-center gap-1 text-[11px] font-bold text-rose-300 bg-rose-500/20 px-2.5 py-1 rounded-xl border border-rose-500/40 animate-pulse">
                    <CheckCircle2 className="w-3.5 h-3.5 text-rose-400" />
                    Seçildi
                  </span>
                )}
              </div>
            </div>

            {/* Orta Kısım: Başlık & Açıklama */}
            <div>
              <h3 className="text-xl sm:text-2xl font-black text-white group-hover:text-rose-100 transition-colors tracking-tight flex items-center gap-2">
                <span>MM2 Bıçak, Silah & Set Pazarı</span>
              </h3>
              <p className="text-xs text-zinc-300 mt-1.5 line-clamp-2 leading-relaxed">
                Corrupt, Harvester, Batwing, Icepiercer, Chroma ve Godly eşyalar için Discord üzerinden doğrudan güvenle anlaşın.
              </p>
            </div>

            {/* Popüler Etiketler */}
            <div className="flex flex-wrap gap-1.5">
              {['#Godly', '#Ancient', '#Chroma', '#CorruptSet', '#SilahTakası'].map((tag) => (
                <span
                  key={tag}
                  className="text-[10px] font-mono px-2 py-0.5 rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-400 group-hover:border-rose-500/30 group-hover:text-rose-300 transition-colors"
                >
                  {tag}
                </span>
              ))}
            </div>

            {/* Öne Çıkan MM2 İtem Thumbnail'leri */}
            <div className="pt-3 border-t border-zinc-800/80 flex items-center justify-between gap-3 flex-wrap">
              <div className="flex items-center gap-2">
                {mm2FeaturedItems.map((item) => (
                  <div
                    key={item.name}
                    className="w-10 h-10 rounded-xl bg-zinc-900/90 border border-zinc-800 flex items-center justify-center p-1 group-hover:border-rose-500/40 transition-all hover:scale-110 shadow-sm relative"
                    title={`${item.name} (${item.rarity})`}
                  >
                    <img
                      src={item.img}
                      alt={item.name}
                      className="w-full h-full object-contain filter drop-shadow-[0_2px_4px_rgba(0,0,0,0.6)]"
                      onError={(e: any) => {
                        e.currentTarget.style.display = 'none';
                      }}
                    />
                  </div>
                ))}
              </div>

              <div className="flex items-center gap-1.5 text-xs font-bold text-rose-400 group-hover:text-rose-300 transition-all">
                <span>{selectedGame === 'MM2' ? 'Filtreyi Temizle' : 'MM2 İlanlarını Listele'}</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
              </div>
            </div>

          </div>
        </div>

        {/* =========================================
            2. ADOPT ME! KATEGORİ KARTI
           ========================================= */}
        <div
          onClick={() => onSelectGame(selectedGame === 'Adopt Me!' ? 'ALL' : 'Adopt Me!')}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              onSelectGame(selectedGame === 'Adopt Me!' ? 'ALL' : 'Adopt Me!');
            }
          }}
          className={`relative group rounded-3xl overflow-hidden p-5 sm:p-6 border transition-all duration-300 cursor-pointer text-left select-none ${
            selectedGame === 'Adopt Me!'
              ? 'bg-gradient-to-br from-emerald-950/90 via-zinc-950 to-zinc-950 border-emerald-500 shadow-[0_0_35px_rgba(16,185,129,0.35)] ring-2 ring-emerald-500/80 scale-[1.01]'
              : 'bg-zinc-950/80 hover:bg-zinc-900/90 border-zinc-800/90 hover:border-emerald-500/60 hover:shadow-xl hover:shadow-emerald-950/30'
          }`}
        >
          {/* Arka plan süzülen neon rengi & parıltı */}
          <div className="absolute -top-16 -right-16 w-56 h-56 bg-emerald-600/20 rounded-full blur-3xl group-hover:bg-emerald-600/30 transition-all pointer-events-none" />
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-emerald-600 via-teal-500 to-emerald-700 opacity-60 group-hover:opacity-100 transition-opacity" />

          <div className="relative z-10 flex flex-col justify-between h-full space-y-4">
            
            {/* Üst Kısım: Rozet ve İlan Sayacı */}
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-xl shadow-inner group-hover:scale-105 transition-transform">
                  🐾
                </div>
                <div>
                  <div className="text-[11px] font-mono font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                    <span>Adopt Me!</span>
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                  </div>
                  <div className="text-[10px] text-zinc-400 font-mono">Pet & İksir Pazarı</div>
                </div>
              </div>

              <div className="flex items-center gap-1.5">
                <span className="px-3 py-1 rounded-xl bg-emerald-950/90 border border-emerald-500/40 text-emerald-300 text-xs font-mono font-bold shadow-sm">
                  {adoptMeListingsCount} İlan Aktif
                </span>
                {selectedGame === 'Adopt Me!' && (
                  <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-300 bg-emerald-500/20 px-2.5 py-1 rounded-xl border border-emerald-500/40 animate-pulse">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    Seçildi
                  </span>
                )}
              </div>
            </div>

            {/* Orta Kısım: Başlık & Açıklama */}
            <div>
              <h3 className="text-xl sm:text-2xl font-black text-white group-hover:text-emerald-100 transition-colors tracking-tight flex items-center gap-2">
                <span>Adopt Me! Pet & İksir Pazarı</span>
              </h3>
              <p className="text-xs text-zinc-300 mt-1.5 line-clamp-2 leading-relaxed">
                Shadow Dragon, Bat Dragon, Frost Dragon, Mega Neon petler, Fly & Ride iksirleri ilanlarını keşfedin.
              </p>
            </div>

            {/* Popüler Etiketler */}
            <div className="flex flex-wrap gap-1.5">
              {['#Legendary', '#MegaNeon', '#FlyRide', '#ShadowDragon', '#PetPazarı'].map((tag) => (
                <span
                  key={tag}
                  className="text-[10px] font-mono px-2 py-0.5 rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-400 group-hover:border-emerald-500/30 group-hover:text-emerald-300 transition-colors"
                >
                  {tag}
                </span>
              ))}
            </div>

            {/* Öne Çıkan Adopt Me İtem Thumbnail'leri */}
            <div className="pt-3 border-t border-zinc-800/80 flex items-center justify-between gap-3 flex-wrap">
              <div className="flex items-center gap-2">
                {adoptMeFeaturedItems.map((item) => (
                  <div
                    key={item.name}
                    className="w-10 h-10 rounded-xl bg-zinc-900/90 border border-zinc-800 flex items-center justify-center p-1 group-hover:border-emerald-500/40 transition-all hover:scale-110 shadow-sm relative"
                    title={`${item.name} (${item.rarity})`}
                  >
                    <img
                      src={item.img}
                      alt={item.name}
                      className="w-full h-full object-contain filter drop-shadow-[0_2px_4px_rgba(0,0,0,0.6)]"
                      onError={(e: any) => {
                        e.currentTarget.style.display = 'none';
                      }}
                    />
                  </div>
                ))}
              </div>

              <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400 group-hover:text-emerald-300 transition-all">
                <span>{selectedGame === 'Adopt Me!' ? 'Filtreyi Temizle' : 'Adopt Me! İlanlarını Listele'}</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
              </div>
            </div>

          </div>
        </div>

      </div>
    </div>
  );
};
