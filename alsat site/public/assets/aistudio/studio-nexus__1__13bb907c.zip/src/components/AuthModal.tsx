import React, { useState } from 'react';
import {
  ShieldCheck,
  Lock,
  User as UserIcon,
  AlertCircle,
  ArrowRight,
  Eye,
  EyeOff,
  Check,
} from 'lucide-react';
import { AuthResponse } from '../types/auth';
import { validateUsername } from '../utils/validation';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAuthSuccess: (data: AuthResponse) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, onAuthSuccess }) => {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [passwordConfirm, setPasswordConfirm] = useState('');

  // Şifre göster / gizle state'leri
  const [showPassword, setShowPassword] = useState(false);
  const [showPasswordConfirm, setShowPasswordConfirm] = useState(false);

  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  // Canlı Girdi Doğrulama Durumları
  const nameValidation = validateUsername(name);
  const isNameValid = nameValidation.isValid;
  const isPasswordValid = password.length >= 6;
  const isPasswordConfirmValid =
    passwordConfirm.length >= 6 && password === passwordConfirm;

  const handleModeSwitch = (newMode: 'login' | 'register') => {
    setMode(newMode);
    setErrorMsg(null);
    setPasswordConfirm('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    const cleanName = name.trim();

    // 1. Discord İsmi Doğrulama (Maks 10 harf, kesinlikle etiket yok)
    const nameCheck = validateUsername(cleanName);
    if (!nameCheck.isValid) {
      setErrorMsg(nameCheck.error || 'Discord ismi en fazla 10 karakter olmalıdır (Örn: oyuncu).');
      return;
    }

    // 2. Şifre Kriteri: En az 6 karakter
    if (!password || password.length < 6) {
      setErrorMsg('Şifre alanı zorunludur ve en az 6 karakter uzunluğunda olmalıdır.');
      return;
    }

    // 3. Kayıt modunda Şifre Tekrarı Kontrolü
    if (mode === 'register') {
      if (!passwordConfirm) {
        setErrorMsg('Lütfen şifrenizi tekrar girerek doğrulayın.');
        return;
      }

      if (password !== passwordConfirm) {
        setErrorMsg('Girdiğiniz şifreler eşleşmiyor. Lütfen kontrol edin.');
        return;
      }
    }

    setIsLoading(true);

    try {
      const endpoint = mode === 'register' ? '/api/auth/register' : '/api/auth/login';
      const body =
        mode === 'register'
          ? {
              name: cleanName,
              password,
              passwordConfirm,
            }
          : {
              name: cleanName,
              password,
            };

      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'İşlem başarısız oldu.');
      }

      onAuthSuccess(data);
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'Bir hata oluştu.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div className="bg-zinc-900 border border-zinc-700/80 rounded-2xl w-full max-w-md shadow-2xl overflow-hidden p-6 animate-in fade-in zoom-in-95 duration-150 my-auto">
        {/* Başlık ve Kapat Butonu */}
        <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-purple-600/20 border border-purple-500/40 flex items-center justify-center text-purple-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-black text-white">
                {mode === 'login' ? 'Giriş Yap' : 'Kayıt Ol'}
              </h2>
              <p className="text-xs text-zinc-400">Alsat Pazar Hesabınız (Etiketsiz)</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-zinc-400 hover:text-white p-1 text-sm cursor-pointer"
          >
            ✕
          </button>
        </div>

        {/* Tab Geçiş Butonları */}
        <div className="grid grid-cols-2 gap-2 p-1 bg-zinc-950 rounded-xl my-4 border border-zinc-800">
          <button
            type="button"
            onClick={() => handleModeSwitch('login')}
            className={`py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
              mode === 'login'
                ? 'bg-zinc-800 text-white shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Giriş Yap
          </button>
          <button
            type="button"
            onClick={() => handleModeSwitch('register')}
            className={`py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
              mode === 'register'
                ? 'bg-zinc-800 text-white shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Kayıt Ol
          </button>
        </div>

        {/* Hata Mesajı */}
        {errorMsg && (
          <div className="p-3 mb-4 bg-red-950/70 border border-red-500/40 text-red-200 text-xs rounded-xl flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Form Alanı */}
        <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
          {/* 1. Discord İsmi (Kesinlikle etiket yok, maks 10 karakter) */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block font-bold text-zinc-300">
                Discord İsmi <span className="text-purple-400">*</span>
              </label>
              {name.trim() && (
                <span
                  className={`text-[10px] font-medium flex items-center gap-1 ${
                    isNameValid ? 'text-emerald-400' : 'text-amber-400'
                  }`}
                >
                  {isNameValid ? <Check className="w-3 h-3" /> : 'Maksimum 10 harf'}
                </span>
              )}
            </div>
            <div className="relative">
              <UserIcon className="w-4 h-4 text-purple-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                required
                maxLength={10}
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Discord isminiz (maks. 10 harf)"
                className={`w-full bg-zinc-950 border rounded-xl pl-10 pr-3 py-2.5 text-white placeholder-zinc-500 focus:outline-none transition-colors ${
                  name.trim() && !isNameValid
                    ? 'border-amber-500/80 focus:border-amber-400'
                    : name.trim() && isNameValid
                    ? 'border-emerald-500/80 focus:border-emerald-400'
                    : 'border-zinc-700/80 focus:border-purple-500'
                }`}
              />
            </div>
            <p className="text-[10px] text-zinc-500 mt-1">
              {name.trim() && !isNameValid
                ? nameValidation.error || 'Maks. 10 harf, etiket (#) yok'
                : 'Maksimum 10 harf (etiketsiz, sadece Discord ismi)'}
            </p>
          </div>

          {/* 2. Şifre */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block font-bold text-zinc-300">
                Şifre <span className="text-purple-400">*</span>
              </label>
              {password && (
                <span
                  className={`text-[10px] font-medium flex items-center gap-1 ${
                    isPasswordValid ? 'text-emerald-400' : 'text-amber-400'
                  }`}
                >
                  {isPasswordValid ? <Check className="w-3 h-3" /> : `${password.length}/6 karakter`}
                </span>
              )}
            </div>
            <div className="relative">
              <Lock className="w-4 h-4 text-zinc-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type={showPassword ? 'text' : 'password'}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="En az 6 karakter"
                minLength={6}
                className="w-full bg-zinc-950 border border-zinc-700/80 rounded-xl pl-10 pr-10 py-2.5 text-white placeholder-zinc-500 focus:outline-none focus:border-purple-500"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-zinc-200 transition-colors p-1"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* 3. Şifre Tekrarı (Sadece Kayıt Modunda) */}
          {mode === 'register' && (
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block font-bold text-zinc-300">
                  Şifre Tekrarı <span className="text-purple-400">*</span>
                </label>
                {passwordConfirm && (
                  <span
                    className={`text-[10px] font-medium flex items-center gap-1 ${
                      isPasswordConfirmValid ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {isPasswordConfirmValid ? <Check className="w-3 h-3" /> : 'Şifreler uyuşmuyor'}
                  </span>
                )}
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-zinc-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type={showPasswordConfirm ? 'text' : 'password'}
                  required
                  value={passwordConfirm}
                  onChange={(e) => setPasswordConfirm(e.target.value)}
                  placeholder="Şifrenizi tekrar girin"
                  minLength={6}
                  className={`w-full bg-zinc-950 border rounded-xl pl-10 pr-10 py-2.5 text-white placeholder-zinc-500 focus:outline-none transition-colors ${
                    passwordConfirm && !isPasswordConfirmValid
                      ? 'border-rose-500/80 focus:border-rose-400'
                      : passwordConfirm && isPasswordConfirmValid
                      ? 'border-emerald-500/80 focus:border-emerald-400'
                      : 'border-zinc-700/80 focus:border-purple-500'
                  }`}
                />
                <button
                  type="button"
                  onClick={() => setShowPasswordConfirm(!showPasswordConfirm)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-zinc-200 transition-colors p-1"
                >
                  {showPasswordConfirm ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={
              isLoading ||
              !isNameValid ||
              !isPasswordValid ||
              (mode === 'register' && !isPasswordConfirmValid)
            }
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-purple-600/30 transition-all cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed mt-3"
          >
            {isLoading ? (
              <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <>
                <span>{mode === 'login' ? 'Giriş Yap' : 'Hesabı Oluştur'}</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};
