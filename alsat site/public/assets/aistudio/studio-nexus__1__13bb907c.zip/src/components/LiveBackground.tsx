import React from 'react';

/**
 * LiveBackground Component
 * Arka planda kullanıcının belirttiği https://files.catbox.moe/901ofh.mp4 videosu oynatılır.
 * Kontrast ve okunabilirlik için yarı saydam karartma scrim katmanı yer alır.
 */
export const LiveBackground: React.FC = () => {
  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden" aria-hidden="true">
      {/* 1. Canlı Video Arka Planı (https://files.catbox.moe/901ofh.mp4) */}
      <video
        autoPlay
        loop
        muted
        playsInline
        className="absolute inset-0 w-full h-full object-cover object-center filter brightness-[0.65] contrast-[1.15]"
      >
        <source src="https://files.catbox.moe/901ofh.mp4" type="video/mp4" />
      </video>

      {/* 2. Dinamik Süzülen Neon Işık Halkaları (Hafif Ambient Glow) */}
      <div className="absolute -top-40 -left-40 w-96 h-96 bg-purple-600/20 rounded-full blur-3xl animate-pulse" />
      <div 
        className="absolute top-1/3 -right-32 w-80 h-80 bg-rose-500/15 rounded-full blur-3xl animate-pulse" 
        style={{ animationDuration: '4s' }} 
      />
      <div 
        className="absolute -bottom-20 left-1/3 w-[30rem] h-[30rem] bg-indigo-600/20 rounded-full blur-3xl animate-pulse" 
        style={{ animationDuration: '6s' }} 
      />

      {/* 3. Kontrast ve Okunabilirlik Katmanı */}
      <div className="absolute inset-0 bg-zinc-950/70 backdrop-blur-[1px]" />
      <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/50 to-zinc-950/70" />
    </div>
  );
};
