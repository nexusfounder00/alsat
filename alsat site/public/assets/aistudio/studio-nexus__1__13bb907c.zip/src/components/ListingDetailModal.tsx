import React, { useEffect, useState } from 'react';
import {
  X,
  Copy,
  Check,
  Clock,
  ShieldCheck,
  Tag,
  Maximize2,
  Minimize2,
  MessageSquare,
  Sparkles,
  ArrowRight,
  ExternalLink,
} from 'lucide-react';
import { Listing } from '../types/listing';

interface ListingDetailModalProps {
  listing: Listing | null;
  isOpen: boolean;
  onClose: () => void;
}

export const ListingDetailModal: React.FC<ListingDetailModalProps> = ({
  listing,
  isOpen,
  onClose,
}) => {
  const [copiedDiscord, setCopiedDiscord] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  // ESC tuşuna basıldığında modalı kapat
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  // Modal açıldığında sayfa kaydırmasını kilitle
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  if (!isOpen || !listing) return null;

  const handleCopyDiscord = (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    navigator.clipboard.writeText(listing.ownerDiscordTag);
    setCopiedDiscord(true);
    setTimeout(() => setCopiedDiscord(false), 2500);
  };

  const isMM2 = listing.game === 'MM2';
  const formattedDate = new Date(listing.createdAt).toLocaleDateString('tr-TR', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 bg-black/90 backdrop-blur-xl overflow-y-auto animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className={`relative bg-zinc-950 border border-zinc-800 rounded-3xl shadow-[0_0_50px_rgba(0,0,0,0.8)] flex flex-col transition-all duration-300 overflow-hidden ${
          isFullscreen
            ? 'w-full h-full max-w-none rounded-none'
            : 'w-full max-w-4xl max-h-[92vh] my-auto'
        }`}
      >
        {/* Üst Dekoratif Renk Çizgisi */}
        <div
          className={`h-1.5 w-full bg-gradient-to-r ${
            isMM2
              ? 'from-rose-600 via-red-500 to-amber-500'
              : 'from-emerald-500 via-teal-400 to-cyan-500'
          }`}
        />

        {/* Modal Başlık Çubuğu */}
        <div className="flex items-center justify-between p-4 sm:p-6 border-b border-zinc-800/80 bg-zinc-900/60 backdrop-blur-md">
          <div className="flex items-center gap-3">
            <span
              className={`text-xs font-black uppercase tracking-wider px-3 py-1.5 rounded-xl border flex items-center gap-2 ${
                isMM2
                  ? 'bg-rose-950/80 text-rose-300 border-rose-500/50 shadow-[0_0_15px_rgba(244,63,94,0.3)]'
                  : 'bg-emerald-950/80 text-emerald-300 border-emerald-500/50 shadow-[0_0_15px_rgba(16,185,129,0.3)]'
              }`}
            >
              <span className="font-['Orbitron'] font-black text-[11px] text-white px-1.5 py-0.5 rounded bg-black/40">
                {isMM2 ? 'MM2' : 'ADOPT ME'}
              </span>
              <span className="font-['Rajdhani'] font-bold text-sm tracking-wide">
                {isMM2 ? 'Murder Mystery 2' : 'Adopt Me!'}
              </span>
            </span>

            <span className="hidden sm:flex items-center gap-1 text-xs text-zinc-400 font-mono">
              <Clock className="w-3.5 h-3.5 text-zinc-500" />
              <span>{formattedDate}</span>
            </span>
          </div>

          <div className="flex items-center gap-2">
            {/* Tam Ekran Toggle Butonu */}
            <button
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="p-2 rounded-xl text-zinc-400 hover:text-white hover:bg-zinc-800/80 transition-colors cursor-pointer"
              title={isFullscreen ? 'Küçült' : 'Tam Ekran'}
            >
              {isFullscreen ? (
                <Minimize2 className="w-4 h-4" />
              ) : (
                <Maximize2 className="w-4 h-4" />
              )}
            </button>

            {/* Kapat Butonu */}
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-zinc-400 hover:text-white hover:bg-zinc-800/80 transition-colors cursor-pointer"
              title="Kapat (ESC)"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal İçeriği (Scrollable Alan) */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          
          {/* İlan Başlığı */}
          <div>
            <h1 className="text-xl sm:text-3xl font-black text-white tracking-tight leading-snug">
              {listing.title}
            </h1>
            <div className="sm:hidden flex items-center gap-1.5 text-[11px] text-zinc-500 font-mono mt-1">
              <Clock className="w-3 h-3" />
              <span>{formattedDate}</span>
            </div>
          </div>

          {/* Ana İçerik Grid: Görsel + Detaylar */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            
            {/* Sol Panel: Görsel Alanı (lg: 5 kolon) */}
            <div className="lg:col-span-5 space-y-3">
              {listing.imageUrl ? (
                <div className="rounded-2xl overflow-hidden border border-zinc-800 bg-zinc-900/90 shadow-2xl relative group">
                  <img
                    src={listing.imageUrl}
                    alt={listing.title}
                    className="w-full h-auto max-h-[380px] object-contain mx-auto"
                  />
                  <div className="p-2.5 bg-zinc-950/80 text-[11px] text-zinc-400 font-mono text-center border-t border-zinc-800 flex items-center justify-center gap-1.5">
                    <Sparkles className="w-3 h-3 text-purple-400" />
                    <span>İlan Sahibi Tarafından Yüklenen Görsel</span>
                  </div>
                </div>
              ) : (
                <div className="rounded-2xl border border-zinc-800 bg-zinc-900/40 p-8 text-center flex flex-col items-center justify-center space-y-2 min-h-[220px]">
                  <div className="w-16 h-16 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center font-['Orbitron'] font-black text-lg text-white shadow-inner">
                    {isMM2 ? 'MM2' : 'PETS'}
                  </div>
                  <div className="text-xs font-bold text-zinc-300">
                    {isMM2 ? 'Murder Mystery 2 İlanı' : 'Adopt Me! Pet İlanı'}
                  </div>
                  <div className="text-[11px] text-zinc-500">
                    Bu ilanda özel fotoğraf yüklenmedi
                  </div>
                </div>
              )}

              {/* Güvenli Alışveriş Hatırlatması */}
              <div className="p-3.5 rounded-2xl bg-zinc-900/60 border border-zinc-800/80 space-y-1 text-xs">
                <div className="font-bold text-emerald-400 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>Güvenli Anlaşma Rehberi</span>
                </div>
                <p className="text-[11px] text-zinc-400 leading-relaxed">
                  Discord üzerinden konuşurken oyun içi takas penceresindeki eşyaları iki kez kontrol edin.
                </p>
              </div>
            </div>

            {/* Sağ Panel: İlan Eşyaları & Discord İletişimi (lg: 7 kolon) */}
            <div className="lg:col-span-7 space-y-4">
              
              {/* Verdiğim / Sunduğum Şeyler */}
              <div className="bg-zinc-900/80 rounded-2xl p-4 sm:p-5 border border-emerald-500/30 space-y-2 shadow-sm">
                <div className="text-xs uppercase font-mono font-bold text-emerald-400 tracking-wider flex items-center gap-1.5">
                  <Tag className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Verdiğim / Sunduğum Eşyalar:</span>
                </div>
                <div className="text-sm sm:text-base font-bold text-white whitespace-pre-line leading-relaxed">
                  {listing.offeredItemsText}
                </div>
              </div>

              {/* Aradığım / İstediğim Şeyler */}
              <div className="bg-purple-950/20 rounded-2xl p-4 sm:p-5 border border-purple-500/30 space-y-2 shadow-sm">
                <div className="text-xs uppercase font-mono font-bold text-purple-300 tracking-wider flex items-center gap-1.5">
                  <Tag className="w-3.5 h-3.5 text-purple-400" />
                  <span>Aradığım / İstediğim Eşyalar:</span>
                </div>
                <div className="text-sm sm:text-base font-bold text-zinc-100 whitespace-pre-line leading-relaxed">
                  {listing.lookingForText}
                </div>
              </div>

              {/* İlan Detaylı Açıklaması */}
              <div className="bg-zinc-900/60 rounded-2xl p-4 sm:p-5 border border-zinc-800 space-y-2">
                <div className="text-xs uppercase font-mono font-bold text-zinc-400 tracking-wider flex items-center gap-1.5">
                  <MessageSquare className="w-3.5 h-3.5 text-zinc-400" />
                  <span>İlan Açıklaması:</span>
                </div>
                <p className="text-xs sm:text-sm text-zinc-300 whitespace-pre-line leading-relaxed">
                  {listing.description}
                </p>
              </div>

              {/* Discord İletişim Kartı (Büyük ve Öne Çıkan) */}
              <div className="bg-gradient-to-br from-indigo-950/70 via-zinc-900 to-purple-950/50 rounded-2xl p-5 border border-indigo-500/40 space-y-3.5 shadow-xl">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center text-white font-black text-sm shadow-md">
                      {listing.ownerUsername.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <div className="text-sm font-bold text-white flex items-center gap-1.5">
                        <span>{listing.ownerUsername}</span>
                        <ShieldCheck className="w-4 h-4 text-emerald-400" />
                      </div>
                      <div className="text-xs text-indigo-300 font-mono font-medium">
                        İlan Sahibi Doğrulanmış Discord
                      </div>
                    </div>
                  </div>

                  <span className="hidden sm:inline-flex text-[11px] font-mono font-bold px-2.5 py-1 rounded-lg bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                    Doğrulanmış Discord
                  </span>
                </div>

                {/* Tek Tıkla Kopyala Alanı */}
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 pt-1">
                  <div className="flex-1 bg-zinc-950/90 border border-indigo-500/30 rounded-xl px-3.5 py-2.5 font-mono text-sm sm:text-base font-bold text-white flex items-center justify-between">
                    <span>{listing.ownerDiscordTag}</span>
                    <span className="text-[10px] text-zinc-500 uppercase tracking-widest font-sans">
                      Discord Tag
                    </span>
                  </div>

                  <button
                    onClick={handleCopyDiscord}
                    className={`px-5 py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-lg transition-all cursor-pointer ${
                      copiedDiscord
                        ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-600/30'
                        : 'bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white shadow-indigo-600/30'
                    }`}
                  >
                    {copiedDiscord ? (
                      <>
                        <Check className="w-4 h-4" />
                        <span>Kopyalandı!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4" />
                        <span>Discord Etiketini Kopyala</span>
                      </>
                    )}
                  </button>
                </div>

                <p className="text-[11px] text-zinc-400">
                  💡 Discord uygulamanızı açıp <strong className="text-zinc-200">Arkadaşlar &gt; Arkadaş Ekle</strong> kısmına bu etiketi yapıştırarak ilan sahibine doğrudan mesaj gönderebilirsiniz.
                </p>
              </div>

            </div>
          </div>

        </div>

        {/* Modal Alt Çubuğu */}
        <div className="p-4 sm:p-5 border-t border-zinc-800 bg-zinc-900/80 flex items-center justify-between gap-3">
          <div className="text-xs text-zinc-400 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="hidden sm:inline">İlan Vitrinde Yayında</span>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={handleCopyDiscord}
              className="px-4 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-zinc-700 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              {copiedDiscord ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              <span>{copiedDiscord ? 'Kopyalandı' : 'Discord Kopyala'}</span>
            </button>

            <button
              onClick={onClose}
              className="px-5 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-bold transition-all shadow-md cursor-pointer"
            >
              Kapat
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
