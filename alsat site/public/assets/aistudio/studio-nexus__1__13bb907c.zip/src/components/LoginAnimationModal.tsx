import React, { useEffect, useState } from 'react';
import { ShieldCheck, Check, Sparkles, Hash } from 'lucide-react';

interface LoginAnimationModalProps {
  isOpen: boolean;
  username: string;
  discordTag: string;
  onComplete: () => void;
}

export const LoginAnimationModal: React.FC<LoginAnimationModalProps> = ({
  isOpen,
  username,
  discordTag,
  onComplete,
}) => {
  const [step, setStep] = useState<number>(1);
  const [progress, setProgress] = useState<number>(15);

  useEffect(() => {
    if (!isOpen) {
      setStep(1);
      setProgress(15);
      return;
    }

    // Adım 1: Discord kimliği taranıyor
    const t1 = setTimeout(() => {
      setStep(2);
      setProgress(55);
    }, 450);

    // Adım 2: Pazar ağına bağlanılıyor
    const t2 = setTimeout(() => {
      setStep(3);
      setProgress(90);
    }, 950);

    // Adım 3: Başarılı & Oturum Açıldı
    const t3 = setTimeout(() => {
      setProgress(100);
    }, 1300);

    // Tamamlama & Pazara Giriş
    const t4 = setTimeout(() => {
      onComplete();
    }, 1700);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
      clearTimeout(t4);
    };
  }, [isOpen, onComplete]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-2xl animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-zinc-950 border border-purple-500/50 rounded-3xl p-8 shadow-[0_0_60px_rgba(168,85,247,0.35)] text-center overflow-hidden">
        
        {/* Holografik Arka Plan Işıkları */}
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-purple-600/30 rounded-full blur-3xl pointer-events-none animate-pulse" />
        <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-indigo-600/30 rounded-full blur-3xl pointer-events-none animate-pulse" />
        
        {/* Üst Logo */}
        <div className="mb-6">
          <span className="text-4xl font-normal tracking-[0.25em] text-transparent bg-clip-text bg-gradient-to-r from-purple-100 via-zinc-100 to-indigo-200 drop-shadow-[0_0_18px_rgba(168,85,247,0.5)]">
            𝖆𝖑𝖘𝖆𝖙
          </span>
        </div>

        {/* Dönen Cyber HUD Çemberi */}
        <div className="relative w-24 h-24 mx-auto mb-6 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border-2 border-purple-500/20 animate-ping opacity-30" />
          <div className="absolute inset-0 rounded-full border-2 border-t-purple-500 border-r-indigo-500 border-b-transparent border-l-transparent animate-spin" />
          <div className="w-16 h-16 rounded-2xl bg-zinc-900 border border-purple-500/40 flex items-center justify-center shadow-inner relative z-10">
            {progress === 100 ? (
              <Check className="w-8 h-8 text-emerald-400 animate-in zoom-in-75 duration-200" />
            ) : (
              <Hash className="w-8 h-8 text-indigo-400 animate-pulse" />
            )}
          </div>
        </div>

        {/* Durum Metinleri */}
        <div className="space-y-2 mb-6">
          <h3 className="text-lg font-black text-white tracking-tight">
            {progress === 100 ? 'Giriş Başarılı!' : 'Oturum Açılıyor...'}
          </h3>
          <p className="text-xs font-mono text-indigo-300">
            {step === 1 && 'Kullanıcı kimliği doğrulanıyor...'}
            {step === 2 && 'Alsat Roblox Pazar Ağına bağlanılıyor...'}
            {step === 3 && `${username || discordTag} oturumu aktif ediliyor...`}
          </p>
          <div className="inline-block px-3 py-1 rounded-xl bg-zinc-900/90 border border-zinc-800 text-[11px] font-mono font-bold text-zinc-300">
            Kullanıcı: <span className="text-purple-300">{username || discordTag}</span>
          </div>
        </div>

        {/* İlerleme Çubuğu */}
        <div className="space-y-2">
          <div className="w-full bg-zinc-900 rounded-full h-2 p-0.5 border border-zinc-800 overflow-hidden">
            <div
              className="bg-gradient-to-r from-purple-500 via-indigo-500 to-emerald-400 h-full rounded-full transition-all duration-300 shadow-[0_0_12px_rgba(168,85,247,0.7)]"
              style={{ width: `${progress}%` }}
            />
          </div>
          <div className="flex justify-between items-center text-[10px] font-mono text-zinc-500">
            <span>Bağlantı Şifrelendi</span>
            <span>%{progress}</span>
          </div>
        </div>

      </div>
    </div>
  );
};
