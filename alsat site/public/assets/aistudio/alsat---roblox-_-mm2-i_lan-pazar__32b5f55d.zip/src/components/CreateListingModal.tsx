import React, { useState, useRef } from 'react';
import {
  PlusCircle,
  X,
  AlertCircle,
  ShieldAlert,
  Upload,
  Image as ImageIcon,
  Check,
  RotateCcw,
} from 'lucide-react';
import { User } from '../types/auth';
import { Listing } from '../types/listing';

interface CreateListingModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
  token: string;
  game: 'Adopt Me!' | 'MM2';
  existingListings?: Listing[];
  allowNewListings?: boolean;
  allowImageUploads?: boolean;
  onListingCreated: (newListing: Listing) => void;
}

export const CreateListingModal: React.FC<CreateListingModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  token,
  game,
  existingListings = [],
  allowNewListings = true,
  allowImageUploads = true,
  onListingCreated,
}) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [offeredItemsText, setOfferedItemsText] = useState('');
  const [lookingForText, setLookingForText] = useState('');

  // Dosyadan fotoğraf yükleme state'i (URL değil, gerçek dosya)
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [filePreview, setFilePreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Form alanlarını tamamen sıfırlayan yardımcı fonksiyon
  const resetForm = () => {
    setTitle('');
    setDescription('');
    setOfferedItemsText('');
    setLookingForText('');
    setSelectedFile(null);
    setFilePreview(null);
    setErrorMsg(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // Aynı kullanıcının aynı başlıkta aktif ilanı var mı kontrolü (küçük/büyük harf ve boşluk farkları normalize edilir)
  const normalizedTitle = title.trim().replace(/\s+/g, ' ').toLowerCase();
  const isDuplicateTitle = Boolean(
    normalizedTitle.length >= 4 &&
      existingListings.some(
        (l) =>
          l.ownerId === currentUser.id &&
          l.status === 'ACTIVE' &&
          l.title.trim().replace(/\s+/g, ' ').toLowerCase() === normalizedTitle
      )
  );

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setErrorMsg('Lütfen geçerli bir görsel dosyası (PNG, JPG, WEBP) seçin.');
      return;
    }

    if (file.size > 8 * 1024 * 1024) {
      setErrorMsg('Görsel boyutu en fazla 8MB olabilir.');
      return;
    }

    setSelectedFile(file);
    const reader = new FileReader();
    reader.onloadend = () => {
      setFilePreview(reader.result as string);
    };
    reader.readAsDataURL(file);
    setErrorMsg(null);
  };

  const handleRemoveFile = () => {
    setSelectedFile(null);
    setFilePreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (title.trim().length < 4) {
      setErrorMsg('İlan başlığı en az 4 karakter olmalıdır.');
      return;
    }

    if (isDuplicateTitle) {
      setErrorMsg('Zaten bu başlığa sahip aktif bir ilanınız bulunuyor. Lütfen farklı bir başlık belirleyin.');
      return;
    }

    if (!offeredItemsText.trim()) {
      setErrorMsg('Lütfen verdiğiniz / sunduğunuz eşyaları veya petleri yazın.');
      return;
    }

    if (!lookingForText.trim()) {
      setErrorMsg('Lütfen aradığınız / istediğiniz şeyleri yazın.');
      return;
    }

    if (description.trim().length < 6) {
      setErrorMsg('İlan açıklaması en az 6 karakter olmalıdır.');
      return;
    }

    setIsLoading(true);

    try {
      const res = await fetch('/api/listings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          game,
          title: title.trim(),
          description: description.trim(),
          offeredItemsText: offeredItemsText.trim(),
          lookingForText: lookingForText.trim(),
          imageBase64: filePreview || undefined,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'İlan kaydedilemedi.');
      }

      onListingCreated(data.listing);
      resetForm();
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'İlan oluşturulurken bir hata oluştu.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div className="bg-zinc-900 border border-zinc-700/80 rounded-3xl w-full max-w-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200 my-auto flex flex-col max-h-[92vh]">
        
        {/* Modal Başlığı */}
        <div className="p-4 sm:p-5 border-b border-zinc-800 flex items-center justify-between bg-zinc-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-purple-600/20 border border-purple-500/30 flex items-center justify-center text-purple-400">
              <PlusCircle className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black text-white">Yeni İlan Ver</h2>
                <span
                  className={`text-xs px-2.5 py-0.5 rounded-lg border font-['Rajdhani'] font-bold flex items-center gap-1.5 ${
                    game === 'MM2'
                      ? 'bg-rose-950/80 text-rose-300 border-rose-500/40'
                      : 'bg-emerald-950/80 text-emerald-300 border-emerald-500/40'
                  }`}
                >
                  <span className="font-['Orbitron'] font-black text-[10px] text-white">
                    {game === 'MM2' ? 'MM2' : 'PETS'}
                  </span>
                  <span>{game === 'MM2' ? 'Murder Mystery 2' : 'Adopt Me!'}</span>
                </span>
              </div>
              <p className="text-xs text-zinc-400">
                {game} kategorisinde ilanınız anında listelenir.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={resetForm}
              title="Formu Sıfırla"
              className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors cursor-pointer text-xs flex items-center gap-1"
            >
              <RotateCcw className="w-4 h-4" />
              <span className="hidden sm:inline text-[11px]">Temizle</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Bilgilendirme Notu */}
        <div className="bg-purple-950/30 border-b border-purple-500/20 px-4 py-2.5 text-xs text-purple-300 flex items-center gap-2">
          <ShieldAlert className="w-4 h-4 text-purple-400 shrink-0" />
          <span>
            İlanınıza ilgi duyan oyuncular Discord üzerinden (
            <strong>{currentUser.discordTag || currentUser.username}</strong>) sizinle iletişime geçecektir.
          </span>
        </div>

        {/* İlan Verme İzni Durduruldu Uyarısı */}
        {!allowNewListings && !currentUser.isAdmin && currentUser.username !== '1231321323' && (
          <div className="p-3.5 bg-rose-950/80 border-b border-rose-500/50 text-rose-200 text-xs flex items-center gap-2.5">
            <ShieldAlert className="w-5 h-5 text-rose-400 shrink-0" />
            <div>
              <div className="font-bold">İlan Verme İşlemi Durduruldu!</div>
              <div className="text-[11px] text-rose-300">Yönetici tarafından yeni ilan verme izni geçici olarak askıya alınmıştır.</div>
            </div>
          </div>
        )}

        {/* Yasaklı Üye Uyarısı */}
        {currentUser.isBanned && (
          <div className="p-3.5 bg-rose-950/90 border-b border-rose-500/50 text-rose-200 text-xs flex items-center gap-2.5">
            <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
            <div>
              <div className="font-bold">Hesabınız Yasaklanmıştır!</div>
              <div className="text-[11px] text-rose-300">Güvenlik ve kural ihlali nedeniyle yeni ilan veremezsiniz.</div>
            </div>
          </div>
        )}

        {/* Hata Bildirimi */}
        {errorMsg && (
          <div className="p-3 bg-red-950/70 border-b border-red-500/40 text-red-200 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* İlan Verme Formu (Oyun kategorisi seçimi kaldırıldı, aktif kategoriye doğrudan ilan verilir) */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-6 overflow-y-auto space-y-4 text-xs">
          
          {/* 1. İlan Başlığı (Mükerrer Başlık Koruması ile) */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-zinc-300 font-bold">
                İlan Başlığı <span className="text-purple-400">*</span>
              </label>
              {title.trim().length >= 4 && (
                <span
                  className={`text-[10px] font-medium flex items-center gap-1 ${
                    isDuplicateTitle ? 'text-rose-400' : 'text-emerald-400'
                  }`}
                >
                  {isDuplicateTitle ? (
                    'Bu başlıkta aktif bir ilanınız zaten var'
                  ) : (
                    <>
                      <Check className="w-3 h-3" /> Başlık uygun
                    </>
                  )}
                </span>
              )}
            </div>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder={
                game === 'MM2'
                  ? 'Örn: Harvester & Corrupt Set Takaslık'
                  : 'Örn: FR Shadow Dragon & Neon Frost Takaslık'
              }
              className={`w-full bg-zinc-950 border rounded-xl px-3.5 py-2.5 text-white placeholder-zinc-500 focus:outline-none transition-colors ${
                isDuplicateTitle
                  ? 'border-rose-500/80 focus:border-rose-400'
                  : 'border-zinc-700/80 focus:border-purple-500'
              }`}
            />
            {isDuplicateTitle ? (
              <p className="text-[10px] text-rose-400 mt-1">
                Aynı başlıkla mükerrer ilan verilemez. Lütfen başlığa detay ekleyin veya değiştirin.
              </p>
            ) : (
              <p className="text-[10px] text-zinc-500 mt-1">
                İlanınızın ana temasını belirten net ve anlaşılır bir başlık girin.
              </p>
            )}
          </div>

          {/* 2. Verdiğim / Sunduğum Eşyalar */}
          <div>
            <label className="block text-zinc-300 font-bold mb-1">
              Verdiğim / Sunduğum Şeyler <span className="text-emerald-400">*</span>
            </label>
            <textarea
              required
              rows={2}
              value={offeredItemsText}
              onChange={(e) => setOfferedItemsText(e.target.value)}
              placeholder={
                game === 'MM2'
                  ? 'Örn: Harvester (Ancient), Batwing (Godly), Chroma Gemstone...'
                  : 'Örn: Fly Ride Shadow Dragon, NFR Frost Dragon, Ride Potion...'
              }
              className="w-full bg-zinc-950 border border-zinc-700/80 rounded-xl p-3 text-white placeholder-zinc-500 focus:outline-none focus:border-purple-500"
            />
          </div>

          {/* 3. Aradığım / İstediğim Eşyalar */}
          <div>
            <label className="block text-zinc-300 font-bold mb-1">
              Aradığım / İstediğim Şeyler <span className="text-purple-400">*</span>
            </label>
            <textarea
              required
              rows={2}
              value={lookingForText}
              onChange={(e) => setLookingForText(e.target.value)}
              placeholder={
                game === 'MM2'
                  ? 'Örn: Corrupt Set veya benzer değerde Godly bıçaklar...'
                  : 'Örn: Mega Neon Cow, Giraffe veya iyi teklifler...'
              }
              className="w-full bg-zinc-950 border border-zinc-700/80 rounded-xl p-3 text-white placeholder-zinc-500 focus:outline-none focus:border-purple-500"
            />
          </div>

          {/* 4. Açıklama & Notlar */}
          <div>
            <label className="block text-zinc-300 font-bold mb-1">
              Açıklama / Takas Şartları <span className="text-purple-400">*</span>
            </label>
            <textarea
              required
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Örn: Discord'dan ekleyip yazabilirsiniz, gün içinde aktifim. Roblox içi takas yapacağız."
              className="w-full bg-zinc-950 border border-zinc-700/80 rounded-xl p-3 text-white placeholder-zinc-500 focus:outline-none focus:border-purple-500"
            />
          </div>

          {/* 5. Fotoğraf Yükleme (Dosyadan Gerçek Yükleme) */}
          <div>
            <label className="block text-zinc-300 font-bold mb-1">
              İlan Görseli <span className="text-zinc-500 font-normal">(İsteğe bağlı, cihazdan yükle)</span>
            </label>
            <div className="space-y-2">
              <input
                ref={fileInputRef}
                type="file"
                accept="image/png,image/jpeg,image/webp,image/gif"
                onChange={handleFileChange}
                className="hidden"
              />

              {filePreview ? (
                <div className="relative rounded-2xl overflow-hidden border border-zinc-700 bg-zinc-950 max-h-48 flex items-center justify-center p-2">
                  <img
                    src={filePreview}
                    alt="Seçilen görsel"
                    className="max-h-44 object-contain rounded-xl"
                  />
                  <button
                    type="button"
                    onClick={handleRemoveFile}
                    className="absolute top-3 right-3 p-1.5 rounded-xl bg-black/80 hover:bg-red-600 text-white transition-colors cursor-pointer text-xs"
                    title="Görseli kaldır"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full py-4 border-2 border-dashed border-zinc-700 hover:border-purple-500 rounded-2xl flex flex-col items-center justify-center gap-1.5 text-zinc-400 hover:text-white transition-colors cursor-pointer bg-zinc-950/40"
                >
                  <Upload className="w-5 h-5 text-purple-400" />
                  <span className="font-semibold text-xs">Cihazınızdan Fotoğraf Seçin</span>
                  <span className="text-[10px] text-zinc-500">PNG, JPG veya WEBP (Maks. 8MB)</span>
                </button>
              )}
            </div>
          </div>

          {/* Form Alt Aksiyon Butonları */}
          <div className="pt-2 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              disabled={isLoading}
              className="px-4 py-2.5 rounded-xl text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors cursor-pointer font-bold"
            >
              İptal
            </button>
            <button
              type="submit"
              disabled={
                isLoading ||
                isDuplicateTitle ||
                currentUser.isBanned ||
                (!allowNewListings && !currentUser.isAdmin && currentUser.username !== '1231321323')
              }
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold flex items-center gap-2 shadow-lg shadow-purple-600/30 transition-all cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <PlusCircle className="w-4 h-4" />
                  <span>
                    {!allowNewListings && !currentUser.isAdmin && currentUser.username !== '1231321323'
                      ? 'İlan Verme Durduruldu'
                      : `${game} İlanını Yayınla`}
                  </span>
                </>
              )}
            </button>
          </div>

        </form>
      </div>
    </div>
  );
};
